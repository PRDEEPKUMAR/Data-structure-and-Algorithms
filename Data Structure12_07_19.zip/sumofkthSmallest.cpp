#include<iostream>
#include<bits/stdc++.h>
using namespace std;
struct Node
{
    int data;
    struct Node *right;
    struct Node *left;
    struct Node *nextRight;
};
struct Node* insertBST(struct Node *r,int val)
{
    if(r==NULL)
    {
      r=(struct Node*)malloc(sizeof(struct Node));
        r->left=r->right=NULL;
        r->data=val;
        return r;

    }
    else if(val<r->data)
    {
    r->left=insertBST(r->left,val);
    }
    else if(val>r->data)
       r->right=insertBST(r->right,val);
    return r;
}
void store(Node* root, vector<int> &v)
{
    if(root==NULL)
    return ;
    store(root->left,v);
    v.insert(v.end(),root->data);
    store(root->right,v);

}
int createWithArray(int A[],int n, int k)
{  Node * root=NULL;
    int i;
    int sum=0,small;
    if(root==NULL)
        root=insertBST(root,A[0]);
    for(i=1;i<n;i++)
    {
        root=insertBST(root,A[i]);
    }
    vector<int> v ;
    store(root,v);
   // cout<<"hi";
    small=v[k-1];
   // cout<<"bye";
    for( i=0;i<v.size();i++)
    {
        cout<<v[i]<<" ";
        if(v[i]<=small)
        sum=sum+v[i];
    }
    return sum;
}

int main()
{
    int t,n;
    cin>>t;
    while(t--)
    {
        cin>>n;
        int sum=0;
        int A[n+1],k;
        for(int i=0;i<n;i++)
        {
            cin>>A[i];
        }
        cin>>k;
        cout<<createWithArray(A,n,k);
        cout<<endl;


    }
    return 0;
}
