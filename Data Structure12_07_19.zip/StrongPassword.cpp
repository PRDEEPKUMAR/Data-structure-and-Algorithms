#include<iostream>
using namespace std;
int main()
{
    int i,len,flag[4]={0},c=0;
    char str[1000];
    cin>>len;
    cin>>str;
   // for(len=0;str[len]!='\0';len++);

        for(i=0;i<len;i++)
        {
            if(str[i]>='a'&&str[i]<='z')
                flag[0]=1;
            if(str[i]>='A'&&str[i]<='Z')
                flag[1]=1;
            if(str[i]>='0'&&str[i]<='9')
                flag[2]=1;
            if(str[i]=='!'||str[i]=='@'||str[i]=='#'||str[i]=='$'||str[i]=='%'||str[i]=='^'||str[i]=='&'||str[i]=='*'||str[i]=='('||str[i]==')'||str[i]=='+'||str[i]=='-')
                flag[3]=1;
        }
        for(int j=0;j<4;j++)
            {if(flag[j]==0)
            c++;}
        //cout<<c;



    if(len<6)
    {

        if(c>(6-len))
        cout<<c;
        else
        cout<<6-len;
    }
    else
        cout<<c;




     return 0;
}
