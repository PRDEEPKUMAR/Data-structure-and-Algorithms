#include<iostream>
using namespace std;

int main()
{
    int n,A[100000],i,j,t,temp,count=0;
    cin>>t;
    while(t--)
    {
    cin>>n;
  for(i=0;i<n;i++)
    cin>>A[i];
  for(i=1;i<n;i++)
  {
      temp=A[i];
      j=i-1;
      while(A[j]>temp&&j>=0)
      {
          A[j+1]=A[j];
          j--;
          count++;
      }
      A[j+1]=temp;
  }
  cout<<count;
    }

    return 0;
}
