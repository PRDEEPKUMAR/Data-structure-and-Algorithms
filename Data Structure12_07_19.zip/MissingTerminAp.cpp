#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,i,sum=0,s=0,d=999999;
        cin>>n;
        int A[n];
        for(i=0;i<n;i++)
        {
            cin>>A[i];
            sum=sum+A[i];

        }
        if(n==2)
        {
            d=(A[1]-A[0])/2;
        }
        else
        {
        for(i=1;i<n;i++)
        {
            if(d>A[i]-A[i-1])
            {
                d=A[i]-A[i-1];
            }
        }
        }
        //cout<<d<<"---\n";
        int m=n;
        n=n+1;
        s=(n*((2*A[0])+((n-1)*d)))/2;
        cout<<s-sum<<endl;

    }
    return 0;
}
