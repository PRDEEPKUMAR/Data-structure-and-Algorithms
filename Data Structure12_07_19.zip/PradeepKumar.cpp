#include<iostream>
using namespace std;
int main()
{
    char str[15];
    int h=1,max=0;
    int H[27],i;
    for(int i=0;i<26;i++)
    {
        cin>>H[i];
    }
    cin>>str;
    for(i=0;str[i]!='\0';i++)
    {
          if(max<H[str[i]-97])
          max=H[str[i]-97];

    }
    cout<<max*i;

    return 0;
}
