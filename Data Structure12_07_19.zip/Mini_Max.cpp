#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main()
{
    vector<int> A;
    int i,val;
    for(i=0;i<5;i++)
    {
        cin>>val;
        A.insert(A.end(),val);
    }
    sort(A.begin(),A.end());
    cout<<A[0]+A[1]+A[2]+A[4]<<" ";
    cout<<A[1]+A[2]+A[3]+A[4];
    return 0;
}

