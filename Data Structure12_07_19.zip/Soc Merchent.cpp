#include<iostream>
using namespace std;
int main()
{
    int sum=0,i,n,A[100],H[101]={0};
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>A[i];
        H[A[i]]++;
    }
    for(i=1;i<=101;i++)
    {
        sum=sum+H[i]/2;
    }

    cout<<sum;

    return 0;
}
