#include<bits/stdc++.h>
using namespace std;

struct node
{
    int data;
    struct node* next;

    node(int x){
        data = x;
        next = NULL;
    }
};
struct TreeNode
{
    int data;
    TreeNode *left;
    TreeNode *right;

    TreeNode(int x){
        data = x;
        left = NULL;
        right = NULL;
    }
};
void push(struct node** head_ref, int new_data)
{
    struct node* new_node = new node(new_data);
    new_node->next = (*head_ref);
    (*head_ref)    = new_node;
}
void convert(node *head,TreeNode * &root);
void lvl (TreeNode *r)
{
    if(r==NULL)
        return;
    queue<TreeNode *> q;
    q.push(r);
    while(!q.empty())
    {
        TreeNode * j = q.front();
        cout<<j->data<<" ";
        q.pop();
        if(j->left)
            q.push(j->left);
        if(j->right)
            q.push(j->right);
    }
}
void reverses(node **head)
{
    node *prev=NULL;
    node *cur = *head;
    node *nxt;
    while(cur!=NULL)
    {
        nxt = cur->next;
        cur->next = prev;
        prev = cur;
        cur = nxt;
    }
    *head = prev;
}
/* Driver program to test above function*/
int main()
{
  int T,i,n,l,k;
    cin>>T;
    while(T--){
    struct node *head = NULL;
        cin>>n;
        for(i=1;i<=n;i++)
        {
            cin>>l;
            push(&head,l);
        }
        reverses(&head);
    TreeNode *root=NULL;
    convert(head,root);
if(root==NULL)
cout<<"-1";
lvl(root);
cout<<endl;
   // inorder(root);
    getchar();
    }
    return 0;
}





/*
The structure of Link list node is as follows
struct node
{
    int data;
    struct node* next;
};
The structure of TreeNode is as follows
struct TreeNode
{
    int data;
    TreeNode *left;
    TreeNode *right;
};
*/
/*You are required to complete this method*/
void printQueue(queue<TreeNode*> q)
{
	//printing content of queue
	while (!q.empty()){
		cout<<" "<<q.front()->data;
		q.pop();
	}
	cout<<endl;
}
void convert(node *head,TreeNode *&root)
{
   // cout<<"Madar";
  node* h=head;
  TreeNode* temp;
  root=new TreeNode(head->data);
  TreeNode* r=root;
  queue<TreeNode* > q;
  q.push(root);
  int i=0;
  while(h->next!=NULL)
  {
      temp=q.front();
      //cout<<temp->data<<" ";
      q.pop();
      if(h->next)
      {
        //  cout<<"if one";
          h=h->next;
          temp->left=new TreeNode(h->data);

      }
      if(h->next)
      {
         // cout<<"if two";
          h=h->next;
          temp->right=new TreeNode(h->data);
      }
      if(temp->left)
      q.push(temp->left);
      if(temp->right)
      q.push(temp->right);

  }

}
