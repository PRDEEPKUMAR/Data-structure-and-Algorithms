#include <bits/stdc++.h>
using namespace std;

#define range(i,n) for(i=0;i<n;i++)
#define square(n)  n*n

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    long long n,k,val,i,j,g=0,f,s;
    cin>>n>>k;
    priority_queue<long long ,vector<long long>,greater<long long>> pq;
    range(i,n)
    {
        cin>>val;
        pq.push(val);
    }
    int count=0;
    while(pq.top()<=k&&count<n-1)
    {
        f=pq.top();
        pq.pop();
        s=pq.top();
        pq.pop();
        g=f*1+s*2;
        pq.push(g);
        count++;
    }
    if(count==n-1&&pq.top()<k)
        cout<<-1;
    else
       cout<<count;
    return 0;

}
