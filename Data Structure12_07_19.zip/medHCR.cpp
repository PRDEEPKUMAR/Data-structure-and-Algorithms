#include<iostream>
#include<vector>
#include<algorithm>
#include<stdio.h>
using namespace std;
int main()
{
    float val;
    float m;
  vector<float> V;
  int n;
  cin>>n;
  for(int i=0;i<n;i++)
  {
      cin>>val;
      V.insert(V.end(),val);
  }
  sort(V.begin(),V.end());
  if(n%2==0)
  {
      m=(V[n/2]+V[n/2+1])/2;
      printf("%.1f",m);

  }
  else
  {
      m=V[n/2];
      printf("%.1f",m);
  }
  return 0;
}
