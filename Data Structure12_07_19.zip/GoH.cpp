#include <bits/stdc++.h>
using namespace std;

#define range(i,n) for(i=0;i<n;i++)
#define square(n)  n*n

int main()
{
    int j,i=0,k,t;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    long long sum=0,val,n,g;
    cin>>t;
    int l=1;
    while(t--)
    {
        sum=0,i=0;
    cin>>n;
    int A[1000]={0};
    g=n;
    for(i=0;g>0;i++)
    {

        k=g%10;
        if(k==4)
            A[i]=1;
        else
            A[i]=0;
        g=g/10;
    }
    for(j=i-1;j>=0;j--)
        {

        sum=sum*10+A[j];

        }

       // cout<<sum;
        cout<<"Case #"<<l<<": "<<n-sum<<" "<<sum<<endl;
        l++;
    }
    return 0;
}
