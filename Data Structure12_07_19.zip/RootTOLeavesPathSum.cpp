#include <bits/stdc++.h>
using namespace std;
/* A binary tree node has data, pointer to left child
   and a pointer to right child */
struct Node
{
    int data;
    struct Node* left;
    struct Node* right;
};
/* Helper function that allocates a new node with the
   given data and NULL left and right pointers. */
struct Node* newNode(int data)
{
  struct Node* node = new Node;
  node->data = data;
  node->left = NULL;
  node->right = NULL;
  return(node);
}
/* Function to get diameter of a binary tree */
long long treePathsSum(Node *root);
/* Driver program to test size function*/
int main()
{
  int t;
  scanf("%d", &t);
  while (t--)
  {
     map<int, Node*> m;
     int n;
     scanf("%d",&n);
     struct Node *root = NULL;
     struct Node *child;
     while (n--)
     {
        Node *parent;
        char lr;
        int n1, n2;
        scanf("%d %d %c", &n1, &n2, &lr);
        if (m.find(n1) == m.end())
        {
           parent = newNode(n1);
           m[n1] = parent;
           if (root == NULL)
             root = parent;
        }
        else
           parent = m[n1];
        child = newNode(n2);
        if (lr == 'L')
          parent->left = child;
        else
          parent->right = child;
        m[n2]  = child;
     }
     cout << treePathsSum(root) << endl;
  }
  return 0;
}


/*This is a function problem.You only need to complete the function given below*/
/* Tree node structure  used in the program
 struct Node
 {
     int data;
     Node* left, *right;
}; */
/*You are required to complete below method */
int find_sum_array(long long A[],int n)
{
    int s=0;
    for(int i=0;i<=n;i++)
     {
         s=s*10+A[i];
     }
    return s;
}
void root_to_leaf(Node* t , long long A[], long long i, long long &sum)
{
    int s;
    if(t==NULL) return ;
    else if(!t->left&&!t->right)
    {
        A[i]=t->data;
        s=find_sum_array(A,i);
        sum=sum+s;
    }
    A[i]=t->data;
    root_to_leaf(t->left,A,i+1,sum);
    root_to_leaf(t->right,A,i+1,sum);
}
long long treePathsSum(Node *root)
{
    long long i=0;
    long long sum=0;
    long long A[1000];
    root_to_leaf(root,A,0,sum);
    return sum;

}
