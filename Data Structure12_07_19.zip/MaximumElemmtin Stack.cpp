#include<iostream>
using namespace std;
int main()
{
    int S[1000],top1=-1,top2=-1,Max[1000],max=0,t,val,n;
    cin>>t;
    while(t--)
    {

        cin>>n;
        if(n==1)
        {
            cin>>val;
            if(max<val)
            {
                max=val;
                top2++;
                Max[top2]=max;
            }
            top1++;
            S[top1]=val;
        }
        else if(n==2)
        {
            val=S[top1];
            top1--;
            if(Max[top2]==val)
            {

                top2--;
            }

        }
        else if(n==3)
        {

            cout<<Max[top2];
        }

    }


    return 0;
}
