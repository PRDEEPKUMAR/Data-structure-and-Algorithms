#include<iostream>
#include<bits/stdc++.h>
using namespace std;
void convert(int val,char str[])
{
    int k=val,i=0;
    while(k>0)
    {
        if(k%2==0)
        {
            str[i]='0';
        }
        else{
            str[i]='1';
        }
        k=k/2;
        i++;
    }
    str[i]='\0';

}
int main()
{
    int t,val;
    cin>>t;
    while(t--)
    {
        int n,i,j;
        cin>>val;
        int num=0;
        char str[100];
        convert(val,str);
        for(i=0;i<strlen(str);i++)
        {
            if(i%2==0)
            {
                str[i]='0';
            }
        }
        for(i=0;i<strlen(str);i++)
        {
           if(str[i]=='1')
           {
               num=num+pow(2,i);
           }
        }
        cout<<num<<endl;
    }
    return 0;
}
