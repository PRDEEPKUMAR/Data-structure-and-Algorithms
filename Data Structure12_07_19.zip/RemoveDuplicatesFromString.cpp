#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    cin.ignore();
    while(t--)
    {
        int i;
        string str;
        int  A[256]={0};
        getline (cin, str);
        for(i=0;i<str.length();i++)
        {
            if(A[int(str[i])]==0)
            {
                cout<<str[i];
                A[int(str[i])]=1;
            }
        }
        cout<<endl;
    }
    return 0;
}
