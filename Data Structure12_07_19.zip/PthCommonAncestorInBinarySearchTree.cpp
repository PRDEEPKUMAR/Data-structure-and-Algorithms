#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define MOD 1000000007
struct node{
	int data;
	struct node *left,*right;
};
typedef struct node NODE;
NODE *root=NULL;
NODE* insert(int num,NODE *root);
int pthCommonAncestor(int x,int y,NODE *root,int p,vector<int> &vec);
int main()
{
    int t,n,num,x,y,temp,p;
    scanf("%d",&t);
	while(t--){
		vector<int> vec;
	    NODE *root = NULL;
		vec.clear();
		scanf("%d %d",&n,&p);
		while(n--){
			scanf("%d",&num);
			root=insert(num,root);
		}
		scanf("%d%d",&x,&y);
		if(x>y){
			temp=x;
			x=y;
			y=temp;
		}
		printf("%d",pthCommonAncestor(x,y,root,p,vec));
	}
    return 0;
}
NODE *insert(int num,NODE *root){
	if(root==NULL){
		NODE *temp=(NODE*)malloc(sizeof(NODE));
		temp->data=num;
		temp->left=temp->right=NULL;
		return temp;
	}else if(root->data>=num)root->left=insert(num,root->left);
	else root->right=insert(num,root->right);
	return root;
}

}
/*This is a function problem.You only need to complete the function given below*/
/* The structure of Node
struct Node{
    int data;
    Node *left,*right;
}; */
typedef NODE Node;
void storeAllParent(Node* t, int n, vector<Node*> &v)
{
    if(t==NULL)
      return ;
    else if(n>t->data)
    {
        v.insert(v.end(),t);
        storeAllParent(t->right,n,v);
    }
    else if(n<t->data)
    {
       v.insert(v.end(),t);
       storeAllParent(t->left,n,v);
    }
    else if(n==t->data)
    {
        v.insert(v.end(),t);
        return;
    }
}
int  LCA(Node *root, int n1, int n2, int p)
{
    vector<Node*> v1,v2;
    storeAllParent(root,n1,v1);
    storeAllParent(root,n2,v2);
    int c=v1.size()<v2.size()?v1.size():v2.size();
    int i=0;

        while(v1[i]==v2[i]&&v1[i]!=NULL&&v2[i]!=NULL&&i<c)
            {
                i++;
            }
        if(p>=i)
            {
               return -1;
            }
        else
            {
               return v[i-p]->data;
            }


}

int pthCommonAncestor(int x,int y,NODE *root,int p,vector<int> &vec){
     /*Your code here */
}



