#include <bits/stdc++.h>
using namespace std;
/* A binary tree node has data, pointer to left child
   and a pointer to right child */
struct Node
{
    int data;
    struct Node* left;
    struct Node* right;

    Node(int x){
        data = x;
        left = right = NULL;
    }
};
int maxDiff(Node *root);
int main()
{
  int t;
  struct Node *child;
  scanf("%d", &t);
  while (t--)
  {
     map<int, Node*> m;
     int n;
     scanf("%d",&n);
     struct Node *root = NULL;

     while (n--)
     {
        Node *parent;
        char lr;
        int n1, n2;
        scanf("%d %d %c", &n1, &n2, &lr);
        if (m.find(n1) == m.end())
          {
           parent = new Node(n1);
           m[n1] = parent;
           if (root == NULL)
             root = parent;
          }
        else
        parent = m[n1];
        child = new Node(n2);
        if (lr == 'L')
          parent->left = child;
        else
          parent->right = child;
        m[n2]  = child;
         }
    cout<<maxDiff(root)<<endl;
 }
  return 0;
}
int store(Node* t, int val,vector<int> &v)
{
    int l,r;
    if(t==NULL)
        return 0;
    if(t->data==val)
        return 1;
    l=store(t->left,val,v);
    r=store(t->right,val,v);
    if(l||r)
    {
        v.insert(v.end(),t->data);
    }
}
void kthAncestor(Node *root, int node ,int &max)
{
    vector<int> v;
    store(root,node,v);
    cout<<"after";
    if(v.size()==0)
        return;
    for(int i=0;i<v.size();i++)
    {
        if(max>v[i]-node)
            max=v[i]-node;
    }
}
void find_max(Node* t,Node *root,int &m)
{
    if(root==NULL)
        return ;
    kthAncestor(root,t->data,m);
    find_max(t->left,root,m);
    find_max(t->right,root,m);
}

int maxDiff(Node* root)
{
    int m=-99999999;
    find_max(root,root,m);
    return m;
}
