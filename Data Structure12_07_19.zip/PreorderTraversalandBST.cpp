#include<bits/stdc++.h>
using namespace std;
struct Node* insertBST(struct Node *r,int val);
Node* createWithArray(int A[],int n);
void preStore(Node* root, vector<int> &v);
bool compare(int A[],int n,vector<int> &v);
struct Node
{
    int data;
    struct Node *right;
    struct Node *left;
};
Node* createWithArray(int A[],int n)
{
    Node* root=NULL;
    int i;
    if(root==NULL)
        root=insertBST(root,A[0]);
    for(i=1;i<n;i++)
    {
        insertBST(root,A[i]);
    }
    return root;
}
struct Node* insertBST(struct Node *r,int val)
{
    if(r==NULL)
    {
      r=(struct Node*)malloc(sizeof(struct Node));
        r->left=r->right=NULL;
        r->data=val;
        return r;

    }
    else if(r->data>val)
    {
    r->left=insertBST(r->left,val);
    }
    else
       r->right=insertBST(r->right,val);
}
void preStore(Node* root, vector<int> &v)
{
    if(root==NULL)
    return ;
    v.insert(v.end(),root->data);
    preStore(root->left,v);
    preStore(root->right,v);
}
bool compare(int A[],int n,vector<int> &v)
{
    int flag;
    for(int i=0;i<n;i++)
    {
        if(A[i]!=v[i])
        {
            return false;
        }
    }
    return true;

}
int main()
{
    int t,n;
    cin>>t;
    while(t--)
    {
        Node* root=NULL;
        cin>>n;
        int A[n],i=0;
        vector<int> v;
        for(i=0;i<n;i++)
        {
            cin>>A[i];
        }
       root= createWithArray(A,n);
       preStore(root,v);
       cout<<compare(A,n,v)<<"\n";
    }
    return 0;
}
