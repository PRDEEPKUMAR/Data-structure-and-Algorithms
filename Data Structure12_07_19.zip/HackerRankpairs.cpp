#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main()
{
    int n,k;
    int val;
    vector<long> v;
    cin>>n>>k;
    for(int i=0;i<n;i++)
     {
        cin>>val;
        v.insert(v.end(),val);
     }
    sort(v.begin(),v.end());
    int l=0;
    for(int i=0;i<v.size();i++)
    {
        if(binary_search(v.begin(),v.end(),v[i]-k))
        {
            cout<<"fuj";
            l++;
        }
    }
    cout<<l;
    return 0;
}
