#include<iostream>
using namespace std;
int main()
 {
     int t,n;
	cin>>t;
	while(t--)
	{
	    cin>>n;
	    int A[n];
	    for(i=0;i<n;i++)
	    {
	        cin>>A[i];
	    }

	}
	return 0;
}
