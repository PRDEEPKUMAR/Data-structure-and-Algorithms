
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
void swapValues(int *a, int *b)
{
    int t=*a;
    *a=*b;
    *b=t;
}
void mergeArray(int A[], int B[],int n, int m)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(A[i]>=B[0])
        {
            swapValues(&A[i],&B[0]);
            sort(B,B+m);

        }
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m,i,val;
        cin>>n>>m;
       priority_queue<int,vector<int>,greater<int>> pq;
        for(i=0;i<n;i++)
        {
            cin>>val;
            pq.push(val);
        }
        for(i=0;i<m;i++)
        {
            cin>>val;
            pq.push(val);
        }
        while(!pq.empty())
        {
            cout<<pq.top()<<" ";
            pq.pop();
        }


    }
    return 0;
}
