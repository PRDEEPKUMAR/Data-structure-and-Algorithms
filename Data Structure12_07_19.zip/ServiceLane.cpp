#include<iostream>
using namespace std;
int main()
{
    int n,t,A[100000],i,j,k,l,min;
    cin>>n>>t;
    for(k=0;k<n;k++)
    {
        cin>>A[k];
    }
    while(t--)
    {

        cin>>i>>j;
        min=999;
        for(k=i;k<=j;k++)
        {
            if(min>A[k])
                min=A[k];

        }
        cout<<min<<endl;

    }


}
