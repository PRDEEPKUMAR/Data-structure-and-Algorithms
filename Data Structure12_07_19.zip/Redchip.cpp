#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    long int t,n,i,j,s,count=0;
    cin>>t;
    while(t--)
    {
        count=2;
        cin>>n;
        for(i=2,j<=n/2;i<=j;i++,j--)
        {
           if(n%i==0||n%j==0)
            {
               // cout<<"i :"<<i<<"j :"<<j<<endl;
                count++;
            }

        }
        if(count%2!=0&&count>3)
            cout<<"Yes"<<endl;
        else
            cout<<"No"<<endl;

    }
   return 0;
}
