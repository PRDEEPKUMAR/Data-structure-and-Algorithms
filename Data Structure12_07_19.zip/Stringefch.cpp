#include<iostream>
using namespace std;
char * intersection(char *s1 ,char *s2)
{

    char temp[1000];
    int i,k=0;
    for(k=0,i=0;(s1[i]!='\0'&&s2[i]!='\0');i++)
    {
        if(s1[i]==s2[i])
         {
             temp[k]=s1[i];
             k++;
         }

    }

}
int main()
{
    int t,n,i;
    cin>>t;
    char str[100][100];
    while(t--)
    {
        cin>>n;
        for(i=0;i<n;i++)
        {
            cin>>str[i];
        }
        for(i=0;i<n-1;i++)
        {

        }


    }
  return 0;
}
