#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    ios_base::sync_with_stdio(true);
    cin.tie(NULL);
    while(1)
        cin>>t;
    return 0;
}
