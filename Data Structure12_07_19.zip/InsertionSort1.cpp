#include<iostream>
using namespace std;

int main()
{
    int n,A[100000],i,j,k,t,temp,count=0;


    cin>>n;
  for(i=0;i<n;i++)
    cin>>A[i];

   for(j=n-2;A[n-1]<A[j];)
      {
          A[j+1]=A[j];
          for(k=0;k<n;k++)
          {

            cout<<A[k]<<" ";
          }
          cout<<"\n";
      }
      A[j+1]=A[n-1];


    return 0;
}

