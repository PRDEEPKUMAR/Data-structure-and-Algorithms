#include<iostream>
using namespace std;
int main()
{
    int  max=-1,n,k;
    cin>>n>>k;
    int A[n];
    for(int i=0;i<n;i++)
       {
           cin>>A[i];
           if(max<A[i])
            max=A[i];
       }
       if(max<=k)
       {
           cout<<0;
       }
       else
       {

           cout<<max-k;
       }

    return 0;
}
