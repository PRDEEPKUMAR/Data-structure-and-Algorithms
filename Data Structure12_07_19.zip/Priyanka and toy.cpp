#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n,val;
    vector<int > v;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>val;
        v.insert(v.end(),val);
    }
    sort(v.begin(),v.end());
int     k=v[0]+4;
    int count=1,f=0;
    for(int i=0;i<n;i++)
    {
        f=0;
        if(v[i]>k)
        {
            count++;
            f=1;
        }
        if(f==1)
        {
            k=*min_element(v.begin()+i,v.end())+4;

        }


    }
    cout<<count;
    return 0;
}
