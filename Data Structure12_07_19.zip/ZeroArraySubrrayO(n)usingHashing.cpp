#include<iostream>
#include<bits/stdc++.h>
using namespace std;
vector<pair<long long int,long long int>> findSubArray(long long int A[], int n)
{
    int i;
    unordered_map<long long int ,vector<long long int>> mp;
    vector<pair<long long int , long long int >> out;
    int sum=0;
    int c=0;
    for(i=0;i<n;i++)
    {
        sum+=A[i];
        if(sum==0)
        {
           // out.push_back(make_pair(sum,i));
            c++;
        }
        if(mp.find(sum)!=mp.end())
        {
            vector<long long int> vc=mp[sum];

             c=c+vc.size();
               //for(auto it=vc.begin();it!=vc.end();it++)
               // out.push_back(make_pair(*it+1,i));

        }
        mp[sum].push_back(i);
    }
     cout<<c<<endl;
    return out;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin>>t;
    while(t--)
    {
        int n,i;
        cin>>n;
        long long int *A=(long long int *)malloc(sizeof(long long int) *n);
        for(i=0;i<n;i++)
            cin>>A[i];
       findSubArray(A,n);

    }
    return 0;
}
