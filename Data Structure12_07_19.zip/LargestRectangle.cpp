#include<iostream>
using namespace std;
int main()
{

    int count=0,max=0,i,j,k,n;
    cin>>n;
    int A[n];
    for(i=0;i<n;i++)
    {
        cin>>A[i];
    }
    for(i=0;i<n;i++)
    {
        j=i-1;
        k=i+1;
        while(j>=0&&(A[i]<A[j]||A[i]==A[j]))
        {
            count++;
            j--;
        }
        while(k<n&&(A[i]<A[k]||A[i]==A[k]))
        {
            count++;
            k++;
        }
        count++;
        if(max<count*A[i])
            max=count*A[i];
        count=0;

    }
    cout<<max;
    return 0;
}
