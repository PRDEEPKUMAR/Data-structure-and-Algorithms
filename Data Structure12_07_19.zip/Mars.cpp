#include<iostream>
using namespace std;
int main()
{
  char str[1000];
  cin>>str;
  int count=0;
  for(int i=0;str[i]!='\0';i=i+3)
  {
      if(str[i]!='S')
      {
        count++;
      }
      if(str[i+1]!='O')
        count++;
      if(str[i+2]!='S')
        count++;
  }
  cout<<count;
    return 0;
}
