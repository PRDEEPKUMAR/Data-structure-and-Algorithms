#include<iostream>
#include<stdio.h>
#include<bits/stdc++.h>
using namespace std;
int BinarySearch(int A[],int l,int u)
{
    int mid;
    if(l==u)
    {
        if(A[l]<A[l-1]&&A[l]<A[l+1])
            return l;
        else
            return -1;
    }
    else
    {
        mid=(l+u)/2;
        if(A[mid]<A[l])
            BinarySearch(A,l,mid-1);
        else if(A[mid]>A[u])
            BinarySearch(A,mid+1,u);
        else if(A[mid]<A[mid-1]&&A[mid]<A[mid+1])
            return mid;

    }
}
int bin(int A[],int low,int high,int item)
{
    int mid=0;
    if(low==high)
    {
        if(A[low]==item)
            return low;
        else
            return -1;
    }
    else
    {
      mid=(low+high)/2;
      if(item<A[mid])
        {
                bin(A,low,mid-1,item);
         }
       else if(item>A[mid])
       {
          // cout<<"higher";
          bin(A,mid+1,high,item);
       }
       else
        {
          return mid;
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t,n,item,x;
    cin>>t;
    while(t--)
    {
        x=-1;
        cin>>n;
        int *A=(int*)malloc(sizeof(int)*n);
        scanf("%d",&A[0]);
        for(int i=1;i<n;i++)
        {
            scanf("%d",&A[i]);
            if(A[i-1]>A[i])
            {
                x=i;
            }
        }
        cin>>item;
        //int x=BinarySearch(A,0,n-1);
       // cout<<x;
        if(x==-1)
           {
              // cout<<"if";
           cout<<bin(A,0,n-1,item)<<endl;
           }
        else if(item>=A[0]&&item<=A[x-1])
        {
           // cout<<"else if 1";
            cout<<bin(A,0,x-1,item)<<endl;
        }
        else if(item>=A[x]&&item<=A[n-1])
        {
           // cout<<"else if 2";
            cout<<bin(A,x,n-1,item)<<endl;
        }
        else
            cout<<-1<<endl;

    }

  return 0;
}
