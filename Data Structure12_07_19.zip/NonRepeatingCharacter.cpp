#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,i,f=0;
        int A[27]={0};
        cin>>n;
        char str[n+1];
        scanf("%s",str);
        for(i=0;i<n;i++)
        {
            int g=str[i]-97;
            A[g]++;
        }
        for(i=0;i<n;i++)
        {
            int g=str[i]-97;
            if(A[g]==1)
            {
                f=1;
                break;
            }
        }
        if(f==0)
        {
            cout<<-1<<endl;
        }
        else
        cout<<str[i]<<endl;

    }
    return 0;
}
