#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;
int  partition(int A[],int low,int high)
{

    int i=low+1,t,j=high,pivot=A[low];
    while(1)
    {
        while(A[i]<pivot&&i<high)
            i++;
        while(A[j]>pivot&&j>low)
            j--;
        if(i<j)
        {
            t=A[i];
            A[i]=A[j];
            A[j]=t;
        }
        else
        {
            A[low]=A[j];
            A[j]=pivot;
            return j;

        }
    }

}
int findk(int A[],int low ,int high,int k)
{
    int q;
    if(low<=high)
    {
        q=partition(A,low,high);
         // cout<<q;
        if(q<k)
        {
           // cout<<"q<k"<<endl;
             findk(A,q+1,high,k);

        }
        else if(q>k)
        {
           // cout<<"q>k"<<endl;

            findk(A,low,q-1,k);
        }
        else if(q==k)
        {
           // cout<<"q=k"<<endl;
            return k;
        }
        else
        {
           // cout<<"q!=k"<<endl;
            return -1;
        }
    }
}
int main()
{
    int t,n,k;
  cin>>t;
  while(t--)
  {
      cin>>n;
      int A[n];
      for(int i=0;i<n;i++)
        scanf("%d",&A[i]);
        cin>>k;
        cout<<A[findk(A,0,n-1,k-1)]<<endl;


  }
    return 0;
}
