#include<iostream>
using namespace std;
struct Node
{

    int data;
    int next;
};
Node *start=NULL;
Node *last=NULL;
void create(int val)
{
    static int a=NULL;
    int b=NULL;
    Node *temp=new Node;
    b=(int)temp;
    temp->data=val;
    temp->next=0;
    if(start==NULL)
    {
    start=temp;
    last=start;
         temp->next=(0^b);
         a=b;

//cout<<a<<"--"<<b<<endl;
    }
    else
    {
       last->next=a^b;
  //     cout<<a<<"--"<<b<<endl;
       last=temp;
       a=b;

    }



}
void display()
{
   //cout<<start->data;
   int a=(int)start;
   int b=start->next;
   int c=a^b;
  // cout<<c<<";

   Node *ptr=(Node*)c;

   int d=c^ptr->next;
   Node *ptr1=(Node*)d;
  cout<<"Pointer :"<<ptr1->data<<endl;


}
void show()
{
    Node *ptr=start;
   int a=(int)start;
   int b=start->next;
   int c=a^b;
   while(b!=0
         )
   {
       cout<<ptr->data<<" ";
        a=(int)ptr;
        b=ptr->next;
        c=a^b;
        ptr=(Node*)c;


}

}
int main()
{
    for(int i=1;i<=5;i++)
        create(i);
    show();
    return 0;



}
