#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int near=-1;
        int i,n,j;
        cin>>n;
        int A[n];
        for(i=0;i<n;i++)
            cin>>A[i];
        for(i=0;i<n;i++)
        {
            near=-1;j=i;
            while(j>=0)
            {
                if(A[j]<A[i])
                {
                    near=A[j];
                    break;
                }
                j--;
            }
            cout<<near<<" ";
        }
    }
    return 0;
}
