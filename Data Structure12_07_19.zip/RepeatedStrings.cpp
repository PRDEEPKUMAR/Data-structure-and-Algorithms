#include<iostream>
using namespace std;
int main()
{
    char s[1000],str[1000];
    int n,len,a=0,k=0,i;
    cin>>s>>n;
    for(int i=0;s[i]!='\0';i++)
    {
        if(s[i]=='a')
            a++;
    }
    for(len=0;s[len]!='\0';len++);
  //  cout<<"len"<<len<<endl;
  //  cout<<"a"<<a<<endl;
    int g=n/len,h=n%len;
   // cout<<"g="<<g<<endl;
   // cout<<"h="<<h<<endl;
    g=g*a;
    for(i=0;i<h;i++)
    {
        if(s[i]=='a')
            k++;
    }
    cout<<g+k;


    return 0;
}
