#include<iostream>
using namespace std;
int main()
{
    int t,n,i,j,sumright=0,sumleft=0;
    cin>>t;
    while(t--)
    {
        cin>>n;
        int A[n];
        for(i=0;i<n;i++)
            cin>>A[i];
        i=0;j=n-1;
        sumleft=0;sumright=0;
        while(i<j)
        {
            if(sumleft<sumright)
                {
                    cout<<"moveleft"<<endl;
                    sumleft=sumleft+A[i];
                    i++;
                }
            else if(sumleft>sumright)
            {
                cout<<"moveright"<<endl;
                sumright=sumright+A[j];
                j--;
            }
        else
        {
            if(A[i]>A[j])
                {
                    sumright=sumright+A[j];
                    j--;
                }
            if(A[j]>A[i])
            {
                sumleft+=A[i];
                i++;
            }
            if(A[i]==A[j])
            {
                sumleft+=A[i];
                sumright+=A[j];
                i++;j--;
            }

        }
        }
        if(sumleft==sumright)
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;

    }
    return 0;
}
