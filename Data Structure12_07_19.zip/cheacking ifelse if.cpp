#include<iostream>
using namespace std;

int main()
{
  if(0)
  {
  cout<<"One";
  }
   if(1)
  {
  cout<<"two";
  }
  else
  {
   cout<<"Three";
  }
  return 0;
}
