#include<iostream>
#include<stdlib.h>
using namespace std;
int strlen(char *str,int *val)
{
    if(str[0]=='\0')
        return 0;
    else
    {
        str++;
        (*val)++;
        return 1+strlen(str,val);
    }

}
int main()
{
    char *s="Hello";
    int a=0;

    cout<<strlen(s,&a)<<endl;
    cout<<"VAlUE OF a "<<a<<endl;

   return 0;
}
