#include<iostream>
using namespace std;
int main()
{
    int i,t,n,k,l;
    cin>>t;
    while(t--)
    {
        int k;
        int pos=0,neg=0;
        cin>>n;
        int A[n],B[n]={0};
        for(i=0;i<n;i++)
        {
            cin>>A[i];
            if(A[i]>0)
                pos++;
            if(A[i]<0)
            {
                neg++;
            }
        }
        for(i=0,k=0;i<n;i++)
        {
            if(A[i]>=0)
           {
               B[k]=A[i];
               k++;
           }
        }
        for(i=0,l=k;i<n;i++)
        {
            if(A[i]<0)
            {
                B[l]=A[i];
                l++;
            }
        }
        for(i=0;i<n;i++)
        {
            cout<<B[i]<<" ";
        }
        cout<<endl;
    }
    return 0;
}
