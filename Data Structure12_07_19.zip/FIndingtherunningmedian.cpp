#include <bits/stdc++.h>
using namespace std;

#define range(i,n) for(i=0;i<n;i++)
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    vector <double> v;
    int n;
    cin>>n;


    return 0;
}
