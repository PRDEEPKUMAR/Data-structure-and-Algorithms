#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,n;
    cin>>t;

    while(t--)
    {
        int miss=0,repeat=0;
        int *A=(int *)malloc(sizeof(int)*1000001);
        int *B=(int *)calloc(1000001,sizeof(int));
        cin>>n;
        for(int i=1;i<=n;i++)
        {
            cin>>A[i];
            B[A[i]]++;
        }
        for(int i=1;i<=n;i++)
        {
            if(B[i]>1)
            {
                repeat=i;
                break;
            }
        }
         for(int i=1;i<=n;i++)
        {
            if(B[i]==0)
            {
                miss=i;
                break;
            }
        }
        cout<<repeat<<" "<<miss<<endl;
    }
    return 0;
}
