#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int val,i,median=0;
        priority_queue<int> max ;
        priority_queue <int, vector<int>, greater<int> > min;
        int n;
        cin>>n;
        for(i=0;i<n;i++)
        {

            cin>>val;
            if(max.size()>min.size())
            {

                if(val<median)
                {
                    t=max.top();
                    max.pop();
                    min.push(t);
                    max.push(val);
                }
                else
                {
                    min.push(val);
                }
                median=int ((max.top()+min.top())/2);
            }
            else if(max.size()<min.size())
            {

                if(val>median)
                {
                    t=min.top();
                    min.pop();
                    max.push(t);
                    min.push(val);
                }
                else
                    max.push(val);
                median=int ((max.top()+min.top())/2);
            }
            else if(max.size()==min.size())
            {
                if(val<median)
                {
                    max.push(val);
                    median=max.top();
                }
                else
                   {

                   min.push(val);
                     median=min.top();
                   }
            }
            cout<<median<<endl;
        }
    }
    return 0;
}
