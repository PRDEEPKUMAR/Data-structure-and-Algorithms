#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int returnGap(long int  gap)
{
    if(gap<=1)
        return 0;
    return gap/2+(gap%2);
}
void swapValues(long int &a,long int &b)
{
    int t=a;
    a=b;
    b=t;
}
void Merge(long int A[], long int B[], long int n ,long int m)
{
    long int i,j, gap=n+m;
    for(gap=returnGap(gap);gap>0;gap=returnGap(gap))
    {
        for(i=0;i+gap<n;i++)
           {
               if(A[i]>A[i+gap])
               swapValues(A[i],A[i+gap]);
           }
        for(j=gap>n?gap-n:0;i<n&&j<m;i++,j++)
        {
            if(A[i]>B[j])
                swapValues(A[i],B[j]);
        }
        for(j=0;j+gap<m;j++)
        {
            if(B[j]>B[j+gap])
                swapValues(B[j],B[j+gap]);
        }
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        long int  n,m,i,j;
        cin>>n>>m;
        long int*A=(long int*)malloc(n*sizeof(long int));
        long int *B=(long int*)malloc(m*sizeof(long int));
        for(i=0;i<n;i++)
        {
            scanf("%ld",&A[i]);
        }
        for(i=0;i<m;i++)
        {
            scanf("%ld",&B[i]);
        }
        Merge(A,B,n,m);
        for(i=0;i<n;i++)
        {
            cout<<A[i]<<" ";
        }
        for(i=0;i<m;i++)
        {
            cout<<B[i]<<" ";
        }
        cout<<endl;
    }
    return 0;
}
