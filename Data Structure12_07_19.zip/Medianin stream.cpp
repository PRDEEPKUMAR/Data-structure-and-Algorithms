#include<bits/stdc++.h>
using namespace std;
int main()
{
    vector<int> v;
    int n,val;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>val;
        v.insert(v.end(),val);
        sort(v.begin(),v.end());
        if(i%2==0)
        {
            cout<<v[i/2]<<endl;
        }
        else
        {
            cout<<(v[i/2]+v[i/2+1])/2<<endl;

        }

    }

   return 0;
}
