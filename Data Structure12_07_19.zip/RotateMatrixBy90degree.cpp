#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        int  A[n][n];
        int a=0,b=0,c=0,d=n-1,e=n-1,f=n-1,g=n-1,h=0,i,j,k;
        int t1=0,t2=0,t3=0,t4=0;
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {

                cin>>A[i][j];
            }
        }
         for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {

                cout<<A[i][j]<<" ";
            }
            cout<<endl;
        }
        cout<<endl<<endl;
        for(i=0,k=n-1;i<k;i++,k--)
        {
            b=i,c=i,f=k,g=k;
            for(j=i;j<k;j++)
            {
                t1=A[i][b];
                t2=A[c][k];
                t3=A[k][f];
                t4=A[g][i];
           // cout<<t1<<" "<<t2<<" "<<t3<<" "<<t4<<endl;

                A[g][i]=t3;
                A[k][f]=t2;
                A[c][k]=t1;
                A[i][b]=t4;
                b++;
                c++;
                f--;
                g--;
            }

        }
        for(i=0,k=n-1;i<n;i++,k--)
        {
            for(j=0;j<n;j++)
            {

                cout<<A[i][j]<<" ";
            }
            cout<<endl;
        }
        cout<<endl;

    }
    return 0;
}
