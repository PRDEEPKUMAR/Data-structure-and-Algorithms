
#include<bits/stdc++.h>
using namespace std;
struct Node{
int data;
Node *left,*right;
};
Node *newNode(int data){
	Node *a=new Node;
	a->data=data;
	a->left=a->right=NULL;
	return a;
}
void insert(Node *root,int a1,int a2,char lr){
	if(root==NULL)
		return;
	if(root->data==a1){
		switch(lr){
			case 'L':root->left=newNode(a2);
			break;
			case 'R':root->right=newNode(a2);
			break;
		}
	}
	else{
		insert(root->left,a1,a2,lr);
		insert(root->right,a1,a2,lr);
	}
}
int mn=0;
int aa[10000];
void printVertical(Node *root);
int main(){
	int t;
	cin>>t;
	while(t--){
		memset(aa,0,sizeof(aa));
		int n;
		cin>>n;
		mn=0;
		Node *root=NULL;
		while(n--){
			int a1,a2;
			char lr;
			cin>>a1>>a2;
			scanf(" %c",&lr);
			if(root==NULL){
				root=newNode(a1);
				switch(lr){
					case 'L':root->left=newNode(a2);
					break;
					case 'R':root->right=newNode(a2);
					break;
				}
			}
			else{
				insert(root,a1,a2,lr);
			}
		}
		printVertical(root);
		cout<<endl;
	}
}
/*This is a function problem.You only need to complete the function given below*/
/*Complete the function below
Node is as follows:
struct Node{
int data;
Node *left,*right;
};
*/
void vot(Node * t, int key,multimap<int , int> &m1)
{
   if(t==NULL)
    return ;
    m1.insert(pair<int , int>(key,t->data));
    vot(t->left,key-1,m1);
    vot(t->right,key+1,m1);
}
void verticalOrder(Node* t)
{
    multimap<int , int> m1;
    vot(t,0,m1);
    for(auto it=m1.begin();it!=m1.end();it++)
    {
        cout<<it->second<<" ";
    }
}
void find_max_min(Node* root,int &min, int &max, int i)
{

    if(root==NULL)
        return ;
    if(min>i)
    {
        min=i;
    }
    if (max<i)
    {
        max=i;
    }
    find_max_min(root->left,min,max,i-1);
    find_max_min(root->right,min,max,i+1);
}
void vot_sum(Node* root,int A[],int i)
{

    if(root==NULL)
        return ;
        A[i]=A[i]+root->data;
    vot_sum(root->left,A,i-1);
    vot_sum(root->right,A,i+1);
}
void printVertical(Node *root)
{
    int min=9999,max=0;
    find_max_min(root,min,max,0);
    int n=(max-min)+1;
    int *A=(int*)calloc(n,sizeof(int));
    vot_sum(root,A,abs(min));
    for(int i=0;i<n;i++)
    {
        cout<<A[i]<<" ";
    }
}
