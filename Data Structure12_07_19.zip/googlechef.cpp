#include<iostream>
using namespace std;
int main()
{
    int  t=0,n,q;
    cin>>t;
    while(t)
    {
        int x=0,y=0;
        int sumy=0,sumx=0;
        cin>>n>>q;
        int X[n],Y[n],D[n];
        for(int i=0;i<n;i++)
         {
           cin>>X[i]>>Y[i]>>D[i];
             if(D[i]=='N'||D[i]=='S')
            {
                y++;
            }
            else if(D[i]=='E'||D[i]=='E')
            {
                x++;
            }

         }
         for(int i=0;i<n;i++)
         {
              if(D[i]=='N'||D[i]=='S')
            {
                sumy=sumy+Y[i];
            }
            else if(D[i]=='E'||D[i]=='E')
            {
                sumx=sumx+X[i];
            }
         }
        cout<<sumx/x<<sumy/y;
         t++;
    }
   return 0;
}
