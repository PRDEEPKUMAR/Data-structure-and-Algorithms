#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
      char str[20005],str2[2005];
      char up[20005],low[2005];
      int A[20005]={0};
    while(t--)
    {
        int i,l=0,k=0,j,n;

      cin>>n;
      cin>>str;
      for(i=0;str[i]!='\0';i++)
      {
          if(str[i]>=97&&str[i]<=122)
       {

           low[l++]=str[i];
       }

          else if(str[i]>=65&&str[i]<=90)
          {
              up[k++]=str[i];
              A[i]=1;
          }

      }
      up[l]='\0';
      low[l]='\0';
      //cout<<"hi1";
      sort(up,up+strlen(up));
      sort(low,low+strlen(low));

        for(i=0,l=0,k=0;str[i]!='\0';i++)
      {
          if(A[i]==0)
            {
                str2[i]=low[k++];
            }
          else if(A[i]==1)
          {
              str2[i]=up[l++];
          }
      }
      str2[i]='\0';
      cout<<str2<<endl;

    }
    return 0;
}
