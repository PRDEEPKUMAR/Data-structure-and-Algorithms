
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,n;
    cin>>t;
    unsigned long long int max,i,j,max_j=0,index_i=0,index_j=0,min_i=999999999999999;
    while(t--)
    {
        max=0;
        min_i=999999999999999;
        max_j=0;
       cin>>n;
       unsigned long long int A[n+1];
       for(i=0;i<n;i++)
       {
           cin>>A[i];
       }
       for(i=0,j=n-1;i<=j;i++,j--)
       {
           if(min_i>A[i])
            {
                min_i=A[i];
                index_i=i;
            }
           if(min_i<A[j])
           {
               max_j=A[j];
               index_j=j;
           }
           if(min_i<max_j)
           {
               cout<<index_j-index_i<<endl;
               cout<<index_i<<"---"<<index_j<<endl;
               break;

           }

       }


    }
    return 0;
}
