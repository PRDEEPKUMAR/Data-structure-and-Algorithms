#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int main()
{
    int num;
    vector<int> V;
    for(int i=0;i<5;i++)
    {

        cin>>num;
        V.push_back(num);
    }

        vector<int>:: iterator iter=V.begin();
        vector<int>:: iterator iter_end=V.end();
        for(int i=0;i<5;i++)
        cout<<iter[i]<<" ";



}
