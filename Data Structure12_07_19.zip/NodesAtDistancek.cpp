#include<bits/stdc++.h>
using namespace std;
#define MAX_HEIGHT 10000
struct Node
{
	int key;
	Node *left, *right;
};
/* utility that allocates a new Node with the given key */
Node* newNode(int key)
{
	Node* node = new Node;
	node->key = key;
	node->left = node->right = NULL;
	return (node);
}
int printKDistantfromLeaf(Node* node, int k);
 void insert(struct Node *root,int n1,int n2,char lr)
 {
     if(root==NULL)
        return;
     if(root->key==n1)
     {
         switch(lr)
         {
          case 'L': root->left=newNode(n2);
                    break;
          case 'R': root->right=newNode(n2);
                    break;
         }
     }
     else
     {
         insert(root->left,n1,n2,lr);
         insert(root->right,n1,n2,lr);
     }
 }
int main()
{
    /* Let us construct the tree shown in above diagram */
    int t,k;
    cin>>t;
    while(t--)
    {
    int n;
    cin>>n;
    struct Node *root=NULL;
    while(n--)
    {
        char lr;
        int n1,n2;
        cin>>n1>>n2;
        cin>>lr;
        if(root==NULL)
        {
            root=newNode(n1);
            switch(lr){
                    case 'L': root->left=newNode(n2);
                    break;
                    case 'R': root->right=newNode(n2);
                    break;
                    }
        }
        else
        {
            insert(root,n1,n2,lr);
        }
    }
    cin>>k;
    cout<<printKDistantfromLeaf(root, k)<<endl;
    }
    return 0;
}

//This function returns the count of the total distinct nodes that are at a
//distance k from leaf nodes.
void count(Node* A[], int n, int k,set<Node*> &s)
{
    if(k>n)
    {
        return ;
    }
    else
    {
        s.insert(A[n-k]);
    }
}
void rootToLeaf(Node* t, int k,int i,Node* A[],set<Node*> &s)
{

    if(t==NULL)
        return;
    if(!t->left&&!t->right)
    {
        count(A,i,k,s);
    }
    A[i]=t;
    rootToLeaf(t->left,k,i+1,A,s);
    rootToLeaf(t->right,k,i+1,A,s);
}
int printKDistantfromLeaf(Node* root, int k)
{
   Node* A[1000]={NULL};
   set<Node*> s;
   rootToLeaf(root,k,0,A,s);
   return s.size();
}
