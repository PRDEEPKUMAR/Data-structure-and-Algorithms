#include <iostream>
#include <queue>
using namespace std;
// A Binary Tree Node
struct node
{
	struct node *left, *right;
	int key;
};
// Method to find next right of given key k, it returns NULL if k is
// not present in tree or k is the rightmost node of its level
node* nextRight(node *root, int k);
// Utility function to create a new tree node
node* newNode(int key)
{
	node *temp = new node;
	temp->key = key;
	temp->left = temp->right = NULL;
	return temp;
}
// A utility function to test above functions
void test(node *root, int k)
{
	node *nr = nextRight(root, k);
	if (nr != NULL)
	cout << nr->key << endl;
	else
	cout << "-1"<<endl;
}
void insert(struct node *root,int n1,int n2,char lr)
 {
     if(root==NULL)
        return;
     if(root->key==n1)
     {
         switch(lr)
         {
          case 'L': root->left=newNode(n2);
                    break;
          case 'R': root->right=newNode(n2);
                    break;
         }
     }
     else
     {
         insert(root->left,n1,n2,lr);
         insert(root->right,n1,n2,lr);
     }
 }
 int main()
{
    /* Let us construct the tree shown in above diagram */
    int t,k;
    cin>>t;
    while(t--)
    {
    int n;
    cin>>n;
    struct node *root=NULL;
    while(n--)
    {
        char lr;
        int n1,n2;
        cin>>n1>>n2;
        cin>>lr;
        if(root==NULL)
        {
            root=newNode(n1);
            switch(lr){
                    case 'L': root->left=newNode(n2);
                    break;
                    case 'R': root->right=newNode(n2);
                    break;
                    }
        }
        else
        {
            insert(root,n1,n2,lr);
        }
    }
    cin>>k;
    test(root,k);
    }
    return 0;
}
typedef struct node Node;
node* nextRight(node *root, int k)
{
    Node* temp;
    queue <Node* > q;
    q.push(root);
    q.push(NULL);
    while(!q.empty())
    {
        temp=q.front();
        q.pop();
        if(temp==NULL&&q.front()==NULL)
            return NULL;
        else if(temp==NULL)
        {

            q.push(NULL);
        }
        else
        {
            if(temp->key==k)
            {
                if(q.front()==NULL)
                    return NULL;
                else
                {
                    return q.front();
                }
            }
            if(temp->left)
                q.push(temp->left);
            if(temp->right)
                q.push(temp->right);
        }
    }
}

}
    for(int k=l;k>=0;k--)
        cout<<A[k]<<" ";
    for(int i=l+1;i<=u+l;i++)
        cout<<A[i]<<" ";
