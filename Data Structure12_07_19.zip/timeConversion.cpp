#inlcude<iostream>
using namespace std;
int main()
{
    string str_m,str_h;
    int h,min;
    cin>>h>>min;
    if(min==0)
    {
        str_m="o'clock";
    }
    else if(min<=30)
    {
        str_m=""
    }
    if(h==1)
        str="one";

    return 0;
}
