#include<iostream>
using namespace std;
int main()
{
  int t,w,b,wc,bc,z;
  cin>>t;
  while(t--)
  {
     cin>>b>>w;
     cin>>bc>>wc>>z;
     if(bc==wc)
     {
         cout<<"zero"<<endl;
         cout<<(bc*b)+(wc*w)<<endl;

     }
     else if(bc>wc&&(wc+z)>=bc)
     {
         cout<<"one"<<endl;
         cout<<(bc*b)+(wc*w)<<endl;
     }
     else if(bc>wc&&(wc+z)<bc)
     {
         cout<<bc<<" "<<wc<<" "<<z;
         cout<<"two"<<endl;
         cout<<(wc*w)+(wc+z)*bc<<endl;

     }
     else if(wc>bc&&bc+z>=wc)
     {
         cout<<"three"<<endl;
         cout<<(bc*b)+(wc*w)<<endl;
     }
     else if(wc>bc&&(bc+z)<wc)
     {
         cout<<"four"<<endl;
         cout<<(bc*b)+(bc+z)*w<<endl;
     }
  }
  return 0;
}
