bool checkBST(Node* t) {
         bool l,r,tr;
    if(t==NULL)
    {
              tr=false;
              return t;
    }
    else if(!t->left&&!t->right)
    {
        tr=true;
        return true;
    }
    else if(t->left&&!t->right)
    {
        if(t->data>t->left->data)
        {

        tr=checkBST(t->left);
            return tr;

        }
        else
        {
            tr=false;
            return false;

        }
    }
    else if(!t->left&&t->right->data)
    {
        if(t->data<t->right->data)
        {
            tr=checkBST(t->right);
            return tr;
        }
        else{
                tr=false;
            return false;
        }
    }
    else if(t->left&&t->right)
    {
        if(t->data>t->left->data&&t->data<t->right->data)
        {
        l= checkBST(t->left);
        r= checkBST(t->right);
         if(l==false)
         {
             tr=l;
            return l;
         }
         else
         {
             tr=r;
            return r;
         }
         }
        else
        {
            tr=false;
            return tr;
        }
    }
    return tr;

}
