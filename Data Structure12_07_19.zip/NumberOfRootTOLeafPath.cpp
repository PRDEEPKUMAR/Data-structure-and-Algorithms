
#include <bits/stdc++.h>
using namespace std;
/* A binary tree node has data, pointer to left child
   and a pointer to right child */
struct Node
{
    int data;
    struct Node* left;
    struct Node* right;
};
void pathCounts( Node* node);
/* Helper function that allocates a new node with the
   given data and NULL left and right pointers. */
struct Node* newNode(int data)
{
  struct Node* node = new Node;
  node->data = data;
  node->left = NULL;
  node->right = NULL;
  return(node);
}
/* Computes the number of nodes in a tree. */
int height(struct Node* node)
{
  if (node==NULL)
    return 0;
  else
    return 1 + max(height(node->left), height(node->right));
}
void inorder(Node *root)
{
    if (root == NULL)
       return;
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}
/* Driver program to test size function*/
int main()
{
  int t;
  scanf("%d", &t);
  while (t--)
  {
     map<int, Node*> m;
     int n;
     scanf("%d",&n);
     struct Node *root = NULL;
     struct Node *child;
     while (n--)
     {
        Node *parent;
        char lr;
        int n1, n2;
        scanf("%d %d %c", &n1, &n2, &lr);
        if (m.find(n1) == m.end())
        {
           parent = newNode(n1);
           m[n1] = parent;
           if (root == NULL)
             root = parent;
        }
        else
           parent = m[n1];
        child = newNode(n2);
        if (lr == 'L')
          parent->left = child;
        else
          parent->right = child;
        m[n2]  = child;
     }
     pathCounts(root);
     cout<< endl;
  }
  return 0;
}
void root_to_leaf(Node* t , int A[], int  i, int &n)
{
    int s;
    if(t==NULL) return ;
    else if(!t->left&&!t->right)
    {
        A[i]++;
         n++;
    }
    root_to_leaf(t->left,A,i+1,n);
    root_to_leaf(t->right,A,i+1,n);
}
void pathCounts(Node *root)
{
     int *A=(int*)calloc(10000,sizeof(int));
    int n=0,i;
    root_to_leaf(root,A,1,n);
    for(i=0;i<=n;i++)
    {
        if(A[i]!=0)
        {
            cout<<i<<" "<<A[i]<<" $";
        }
    }
}
