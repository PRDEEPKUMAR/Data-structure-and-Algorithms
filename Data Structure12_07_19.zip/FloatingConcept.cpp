#include<iostream>
#include<iomanip>
#include<stdio.h>
using namespace std;
int main()
{
    float f=3.0f;
    printf("%f",f);
    return 0;
}
