#include<iostream>
#include<algorithm>
#include<set>
using namespace std;
int main()
{
    int k;
    set<int > myset;
    set<int >::iterator it;
    for(int  i=0;i<4;i++)
    {
        cin>>k;
        myset.insert(k);
    }
    myset.erase(myset.find(40));
    cout<<*myset.begin();

/*for(auto i:myset)
{
    cout<<i<<" ";
}*/

    return 0;
}
