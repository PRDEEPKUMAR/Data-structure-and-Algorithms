#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
    int t ,a,b,l=1;
    cin>>t;
    while(t--)
    {
        int r=0,s=0,p=0;
        cin>>a;
        char str[a][500];
        char *ch;
        for(int i=0;i<a;i++)
        {
            cin>>str[i];
        }
            for(int i=0;i<a;i++)
            {
                if(str[i][0]=='R')
                {
                    r++;
                }
               if(str[i][0]=='P')
                {
                    p++;
                }
                if(str[i][0]=='S')
                {
                    s++;
                }
            }
                if(r&&p&&s)
                    {ch="IMPOSSIBLE";}
                else if(r&&!p&&!s)
                    {ch="P";
                    //cout<<"ne";
                    }

                else if(!r&&p&&!s)
                    {ch="S";}
                else if(!r&&!p&&s)
                    {ch="R";}
                else if(r&&p&&!s)
                {ch="S";}
                else if(!r&&p&&s)
               {

                ch="R";
               }
                else  if(r&&!p&&s)
                    {ch="P";
                    //cout<<"two";
                    }
            cout<<"Case # "<<l<<": "<<ch<<endl;
            l++;

    }
    return 0;
}
