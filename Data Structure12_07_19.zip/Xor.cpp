#include<iostream>
using namespace std;
int main()
{
    int g,t,A[300000],n;
    cin>>t;
    while(t--)
    {

        cin>>n;

        for(int i=1;i<=n;i++)
        {
            cout<<1<<" "<<i<<" "<<i<<" "<<i<<endl;
            cin>>A[i];
        }
        for(int i=1;i<=n;i++)
            cout<<A[i]<" ";
        cout<<endl;
        cin>>g;
        if(g==-1)
            continue;
        else
            cout<<g;
    }
    return 0;
}
