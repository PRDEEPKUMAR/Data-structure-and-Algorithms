#include<iostream>
#include<bits/stdc++.h>
# define ALPHA 26
using namespace std;
struct TrieNode
{

    TrieNode* children[ALPHA];
    bool isEndOfTheWord;
};
TrieNode* getNode()
{
    TrieNode* p=new TrieNode;
    int i;
    for(i=0;i<ALPHA;i++)
    {
        p->children[i]=NULL;
    }
    p->isEndOfTheWord=false;

}
void insertIntoTrie(TrieNode*&root,string key)
{
    struct TrieNode* p=root;
    int i;
    for(i=0;i<key.length();i++)
    {
        int index=key[i]-'a';
        if(!p->children[index])
        p->children[index]=getNode();
        p=p->children[index];
    }
    p->isEndOfTheWord=true;
}
bool searchInTrie(TrieNode* root,string key)
{
    struct TrieNode* p=root;
    int i;
    for(i=0;i<key.length();i++)
    {
        int index=key[i]-'a';
        if(!p->children[index])
            {
                cout<<"gi";
                return false;
            }
        p=p->children[index];
    }
    return  (p!=NULL&&p->isEndOfTheWord);
}

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,i;
        cin>>n;
        struct TrieNode *root=getNode();
        string A[n],key;
        for(i=0;i<n;i++)
        {
            cin>>A[i];
        }
        cin>>key;
        for(i=0;i<n;i++)
        {
            insertIntoTrie(root,A[i]);
        }
        string temp;
        for(i=0;i<key.length();i++)
        {
           temp=temp+key[i];
           cout<<temp<<endl;
          cout<<searchInTrie(root,temp);
        }
    }
    return 0;
}

