#include<iostream>
#include<bits/stdc++.h>
#include<limits.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,i,j,l,k,q=0;
        cin>>n;
        int M[n+1][n+1];
        int A[n+1];


    }
    return 0;
}

