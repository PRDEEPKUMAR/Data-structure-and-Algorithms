#include<stdio.h>
int main()
{

    int A[3][3]={0,0,4,4,2,5,8,6,7};
    int P[15][2];
    int i,j,k=0,l,fr=0,fc=0;
     for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            if(A[i][j]==0)
            {
                P[k][0]=i;
                P[k][1]=j;
                k++;
            }
        }
    }

   for(l=0;l<k;l++)
   {
       for(i=0;i<3;i++)
        {
            for(j=0;j<3;j++)
            {
                if(i==P[l][0]||j==P[l][1])
                {
                    A[i][j]=0;
                }
            }
        }
    }
      for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
    }
    return 0;

}
