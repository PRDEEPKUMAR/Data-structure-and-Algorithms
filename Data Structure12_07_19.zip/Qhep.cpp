#include<iostream>
#include<algorithm>
#include<set>
using namespace std;
int main()
{
    set<int> myset;
    int t,val,q;
    set<int>::iterator it;
    cin>>t;
    while(t--)
    {

        cin>>q;
        if(q==1)
        {
            cin>>val;
            myset.insert(val);
        }
        else if(q==2)
        {
            cin>>val;
             myset.erase(myset.find(val));
        }
        else if(q==3)
        {
            cout<<*myset.begin()<<endl;
        }
    }
}
