#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<vector>
using namespace std;
struct Knapsack
{
    double weight;
    double value;
    double rate;
    Knapsack(int w,int v)
    {
        weight=w;
        value=v;
        rate=value/weight;
    }

};
bool cmp(struct Knapsack k1,struct Knapsack k2)
{

    double d1=k1.value/k1.weight;
    double d2=k2.value/k2.weight;
    return d1>d2;
}
int  main()
{
    int t,n,k,w,v,kt;
    double sum=0.0;
    cin>>t;
    while(t--)
    {
        vector<Knapsack> V;
        sum=0.0;
        cin>>n>>k;
        kt=k;
        double S[n]={0.0};
        for(int i=0;i<n;i++)
        {
            cin>>v>>w;
            V.push_back(Knapsack(w,v));

        }
        sort(V.begin(),V.end(),cmp);
        for(int i=0;i<n;i++)
        {
            //cout<<V[i].weight<<" "<<kt;
                if(V[i].weight<kt)
                {

                 S[i]=(double)V[i].value;
                 kt=kt-V[i].weight;
                }
                else
                {
                    //cout<<"Two";
                   // cout<<"Rate :"<<V[i].rate;
                    S[i]=(double)kt*(V[i].rate);
                    break;
                }
        }
        for(int i=0;i<n;i++)
        {
           // cout<<V[i].weight<<" "<<V[i].value<<" ";
          // cout<<S[i]<<endl;
            sum=sum+S[i];
        }
        if((sum-(int)sum)==.50)
        printf("%0.2f\n",sum);
        else
        {
            sum=(int)sum;
            printf("%0.2f\n",sum);
        }
    }
}
