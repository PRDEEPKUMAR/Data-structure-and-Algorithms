#include<iostream>
using namespace std;
int main()
{
    int x,y,z;
    cout<<1;
    cin>>y;
    if(y==2)
        cout<<3;
    else
        cout<<2;


    return 0;
}
