#include<iostream>
#include<math.h>
using namespace std;
long findDigits(long val)
{
    long c=0;
    while(val>0)
    {
        val=val/10;
        c++;
    }
    return c;
}
long karpaker(long n)
{

    long p=1,sq=n*n;
    long f=findDigits(sq);
    long g=findDigits(n);
    for(int i=1;i<=g;i++)
        p=p*10;
    long r=(sq/p)+(sq%p);
   /* cout<<"f:"<<f<<endl;
     cout<<"g :"<<g<<endl;
      cout<<"p :"<<p<<endl;
       cout<<"r :"<<r<<endl;*/
    if(r==n)
    {
        return n;
    }
    else
        return -1;



}
int main()
{
    long p,q,v;
    int f=0;
    cin>>p>>q;
    if(p==0)
        p=1;
    for(int i=p;i<q;i++)
    {
        v=karpaker(i);
        if(v!=-1)
        {
            f=1;
        cout<<v<<" ";
        }
    }
    if(f==0)
        cout<<"INVALID RANGE";

    return 0;
}
