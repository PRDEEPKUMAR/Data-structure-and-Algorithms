#include<iostream>
#include<stack>
#include<algorithm>
using namespace std;
int main()
{
    stack<int> st;
    int n=10;
    for(int i=0;i<n;i++)
        st.push(i);
    while(!st.empty())
    {
       cout<<st.top();
       st.pop();
    }
    return 0;
}

