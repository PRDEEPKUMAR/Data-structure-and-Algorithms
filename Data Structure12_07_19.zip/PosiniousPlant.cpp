#include<stdio.h>
#include<stdlib.h>
#include<iostream>
  void display();
using namespace std;
struct List
{
    int data;
    struct List *link;
};
struct List *temp,*start=NULL,*last=NULL;
  void insertAtEnd(int num)
  {
      struct List *temp=(struct List*)malloc(sizeof(struct List));
      temp->data=num;
      temp->link=NULL;
      struct List *n=start;
      if(start==NULL)
      {
         last=start=temp;
      }
     else
     {

         last->link=temp;
         last=last->link;
     }

  }
  int return_days()
  {
      struct List *p1,*p2;
      int c=1,f=0;
      if(start==NULL)
        return -1;
      p1=start;
      p2=start->link;
      while(1)
      {f=0;
        p1=start;
        p2=start->link;
          while(p2!=NULL)
            {
                if(p1->data<p2->data)
                {
                    f=1;
                    temp=p2;
                    p2=p2->link;
                    free(p2);
                }
                p1=p2;
                p2=p2->link;
            }
            display();
            if(f==0)
            {
                break;
            }

      }
      return c;
  }
  void display()
  {

      struct List *p=start;
      while(p!=NULL)
      {
          cout<<p->data<<" ";
          p=p->link;
      }
      cout<<endl;
  }
int main()
{
    int i,n,val;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>val;
        insertAtEnd(val);
    }
    cout<<return_days();

    return 0;
}
