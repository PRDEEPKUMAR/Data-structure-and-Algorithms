#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        priority_queue<long int,vector<long int>,greater<long int> > pq;
        long int n,i,val,sum=0,t1,t2;
        cin>>n;
        for(i=0;i<n;i++)
        {
            cin>>val;
            pq.push(val);
        }
        i=0;
        while(!pq.empty()&&i<n-1)
        {
            t1=pq.top();
            pq.pop();
            t2=pq.top();
            pq.pop();
          // cout<<t1<<" "<<t2<<endl;;
            sum=sum+t1+t2;
         //   cout<<" "<<sum;
            pq.push(t1+t2);
            i++;
        }
        cout<<sum<<endl;


    }
    return 0;
}
