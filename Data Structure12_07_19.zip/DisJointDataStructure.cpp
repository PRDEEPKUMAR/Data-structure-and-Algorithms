#include<iostream>
#include<vector>
#include<
using namespace std;

int main()
{

    return 0;
}
