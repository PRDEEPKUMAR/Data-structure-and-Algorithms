#include<iostream>
#include<stdio.h>
using namespace std;
void shift(int arr[], int carry , int count)
{
    for(int i=count-1;i>=0;i--)
    {
        arr[i+1]=arr[i];
    }
    arr[0]=carry;
}
int main()
{
    int num;
    cin>>num;
    int sum=0;
    int carry=0;
    int count=0;
    int arr[20];
    arr[0]=1;
    int j=0;
    for(int i=1;i<=num;i++)
    {
        sum=0;
        carry=0;
        for(j=count;j>=0;j--)
        {
            arr[j]=arr[j]*i+carry;
            sum=arr[j]%10;
            carry=arr[j]/10;
            arr[j]=sum;
             printf("%d=c %d=i %d=s\n",carry,i,sum);
        }
        if(carry!=0 && j==0)
        {
            count++;
            shift(arr,carry,count);
        }
    }
    for(int i=0;i<=count;i++)
        cout<<arr[i];

    return 0;
}
