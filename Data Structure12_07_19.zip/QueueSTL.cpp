#include<iostream>
#include<queue>
#include<algorithm>
#include<stdio.h>
#include<conio.h>

using namespace std;
struct Node;
int search(Node*,int );
struct Node
{
    int data;
    struct Node *right;
    struct Node *left;
};
struct Node *root=NULL;
struct Node* insertBST(struct Node *r,int val)
{
    if(r==NULL)
    {
      r=(struct Node*)malloc(sizeof(struct Node));
        r->left=r->right=NULL;
        r->data=val;
        return r;

    }
    else if(r->data>val)
    {
    r->left=insertBST(r->left,val);
    }
    else
       r->right=insertBST(r->right,val);
}
void inOrderNonRecursive(struct Node *ptr)
{
    int top=-1;
    struct Node  *stack[100];
    while(top!=-1||ptr!=NULL)
    {
        if(ptr!=NULL)
        {
            stack[++top]=ptr;
            ptr=ptr->left;
        }
        else
            {
                ptr=stack[top--];
                printf(" %d ",ptr->data);
                ptr=ptr->right;

        }
    }

}
void preOrder(struct Node *r)
{

    if(r==NULL)
        return ;
    printf(" %d  ",r->data);
    preOrder(r->left);
    preOrder(r->right);
}
void create()
{
    int  n;
    char ch='N';
    if(root==NULL)
    {
        printf("Enter the value :-");
        scanf("%d",&n);
        root=insertBST(root,n);
         printf("Press Y to to continue....");
        ch=getch();

    }
        while(ch=='y'||ch=='Y')
    {
         printf("\nEnter the value :-");
        scanf("%d",&n);
        insertBST(root,n);
        printf("Press Y to to continue....");
        ch=getch();

    }

}
void postOrderNonRecursive(struct Node *ptr)
{
    int top=-1;

    struct Node *stack[100];
     xyz:
    while(top!=-1||ptr!=NULL)
    {
       stack[++top]=ptr;
       if(ptr->right!=NULL)
        {
            ptr=ptr->right;
            ptr=ptr;
        }
       ptr=ptr->left;
    }
    ptr=stack[top--];
    if(ptr!=NULL&&top!=-1)
    {

        while(ptr>0)
        {
            printf("%d",ptr->data);
            ptr=stack[top--];
        }
    }
    if(ptr<0)
    {
        ptr=ptr;
        goto xyz;
    }



}
void createWithArray(int A[],int n)
{
    int i;
    if(root==NULL)
        root=insertBST(root,A[0]);
    for(i=1;i<n;i++)
    {
        insertBST(root,A[i]);
    }


}
void nonRecursivePreOrder(struct Node *ptr)
{
    int top=-1;
     struct Node *stack[100];
    top++;
    stack[top]=ptr;
    while(top!=-1)
    {
        ptr=stack[top--];
        if(ptr!=NULL)
        {
            printf(" %d ",ptr->data);
            stack[++top]=ptr->right;
            stack[++top]=ptr->left;
        }
    }
}
void inorder(struct Node *r)
{
    if(r!=NULL)
    {
        inorder(r->left);
        printf(" %d ",r->data);
        inorder(r->right);
    }


}
void postorder(struct Node *r)
{
    if(r!=NULL)
    {
        inorder(r->left);

        inorder(r->right);
        printf(" %d ",r->data);
    }


}
struct Node* findMax(struct Node* r)
{
    if(r==NULL)
    {
        return r;
    }
    else{
        while(r->right!=NULL)
        {
            r=r->right;
        }
        return r;
    }


}

struct Node* delete_Node(struct Node *r,int val)
{
    if(r==NULL)
    {
        printf("Tree Empty");
        return  r;
    }
    if(val>r->data)
    {
        r->right=delete_Node(r->right,val);
        return r;
    }
    else if(val<r->data)
    {
        r->left=delete_Node(r->left,val);
        return r;
    }
    else if(val==r->data)
    {
        if(r->right!=NULL&&r->left!=NULL)
        {
            struct Node *temp=findMax(r->left);
            r->data=temp->data;
            r->left=delete_Node(r->left,r->data);
            return r;


        }
        else if(r->right==NULL&&r->left==NULL)
        {
            free(r);
            return NULL;

        }
        else if(r->left==NULL)
        {
            struct Node *temp=r->right;
            free(r);
            return temp;
        }
        else
        {

            struct Node* temp=r->left;
            free(r);
            return temp;
        }


    }

}

void  level(struct Node* r)
{
    struct Node *ptr=r;
    queue<Node*> qt;
        qt.push(r);
    while(!qt.empty())
        {
            ptr=qt.front();
            qt.pop();
            printf("%d ",ptr->data);
            if(ptr->left!=NULL)
            {
                qt.push(ptr->left);
            }
           if(ptr->right!=NULL)
            {
               qt.push(ptr->right);
            }

        }

}

void  linebyline(struct Node* r)
{
    struct Node *ptr=r;
    struct Node *Queue[100];
    int front=-1,rear=-1;
        front=rear=0;
        Queue[front]=root;
        rear++;
        Queue[rear]=NULL;
    while(front!=rear+1)
        {
            ptr=Queue[front++];
            if(ptr==NULL)
                {
                    if(front!=rear+1)
                    {
                      printf("$ ");
                      rear++;
                      Queue[rear]=NULL;
                    }
                }
            else
           {

            printf("%d ",ptr->data);
            if(ptr->left!=NULL)
            {
                Queue[++rear]=ptr->left;
            }
           if(ptr->right!=NULL)
            {
               Queue[++rear]=ptr->right;
            }
           }

        }
        cout<<"$";

}
int max_node(struct Node *t)
{
    int lmax=0,rmax=0;
    if(t==NULL)
        return 0;
    else if(!t->left&&!t->right)
    {
        return t->data;
    }
    else if(!t->left&&t->right)
    {
        return max_node(t->right);
    }
    else if(t->left&&!t->right)
    {
        return max_node(t->left);
    }
    else
    {
        lmax=max_node(t->left);
        rmax=max_node(t->right);
        if(lmax>rmax)
            return lmax;
        else
            return rmax;
    }
}
 int min_node(struct Node *t)
 {


 }
 int sum_node(struct Node *t)
 {
    int lsum=0,rsum=0;
     if(t==NULL)
        return 0;
     else if(!t->left&&!t->right)
     {

        return t->data;
     }
     else if(t->left&&!t->right)
     {

        return lsum=t->data+sum_node(t->left);
     }
     else if(!t->left&&t->right)
     {
        return rsum=t->data+sum_node(t->right);
     }
     else
     {
         lsum=sum_node(t->left);
         rsum=sum_node(t->right);
         return lsum+rsum+t->data;
     }

 }
 int ls(struct Node *t)
 {
     static int sum=0;
     if(t==NULL)
        return 0;
     else if(!t->left&&!t->right)
     {
         return sum=sum+t->data;
     }
     else
     {
         ls(t->left);
         ls(t->right);
     }


 }
 int  LCA(Node *t , int val1,int val2)
 {
     static int ans=1;
     int left,right;
     if(t==NULL)
        return NULL;
     left=search(t->left,val1);
     right=search(t->right,val2);
     cout<<"\nleft "<<left<<" right "<<right<<endl;
      if(left&&right)
      {
          cout<<"left&&right";
          return t->data;
      }
      else if(left&&!right)
      {
          cout<<"left";
          return LCA(t->left,val1,val2);
      }
      else if(!left&&right)
      {
          cout<<"right";
          return LCA(t->right,val1,val2);
      }
      else if(!left &&!right)
      {
          cout<<" Nahai hai  ";
          return -1;
      }



 }
 int search(Node* t,int val)
 {
     if(t==NULL)
     {
            return 0;
     }
     else if(t->data==val)
     {
         return 1;
     }
     search(t->left,val);
     search(t->right,val);
 }
 int main()
{
    int A[]={50,14,8,23,18,56,45,83,99};
    int B[]={15,25,22,29,24,27,23,7,4,10,6,5,9};
    int c[]={5,3,6,2,7,8};
    createWithArray(c,6);
   printf("Max Node Value :-%d",max_node(root));
    printf("\nSum Node Value :-%d",sum_node(root));
    printf("\n %d :- ",ls(root));
    printf("\nSearched Value : %d\n",search(root,2));
    cout<<"\nLEVEL ORDER TRAVERSAL : ";
    level(root);
   // Node* t=LCA(root,2,8);
   // if(t!=NULL)
  //  printf("\n LeastCommon Ancesstor : %d",LCA(root,3,2));
    //inOrderNonRecursive(root);
    //  printf("\nPreOrder Traversal :-");
   // preOrder(root);
    // printf("\nNon Recursive :-\n");
    // root=delete_Node(root,82);
    // printf("\nAfter Deletion:-");
    // inOrderNonRecursive(root);
    // preOrder(root);
    //nonRecursivePreOrder(root);
    //printf("\nMax :-%d",findMax(root)->data);
    //printf("\nLevel Order Traversal :-");
    //level(root);


    return 0;
}


