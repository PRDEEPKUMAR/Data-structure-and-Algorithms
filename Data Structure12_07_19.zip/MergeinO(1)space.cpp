///Got TLE on Geeks for Geeks Online judge .
///Time Complexity :- O(n*m(log(m)))
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
void swapValues(int *a, int *b)
{
    int t=*a;
    *a=*b;
    *b=t;
}
void mergeArray(int A[], int B[],int n, int m)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(A[i]>=B[0])
        {
            swapValues(&A[i],&B[0]);
            sort(B,B+m);

        }
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m,i;
        cin>>n>>m;
        int A[n+1],B[m+1];
        for(i=0;i<n;i++)
        {
            cin>>A[i];
        }
        for(i=0;i<m;i++)
        {
            cin>>B[i];
        }
        mergeArray(A,B,n,m);
        for(i=0;i<n;i++)
        {
            cout<<A[i]<<" ";
        }
        for(i=0;i<m;i++)
        {
            cout<<B[i]<<" ";
        }
        cout<<endl;


    }
    return 0;
}
