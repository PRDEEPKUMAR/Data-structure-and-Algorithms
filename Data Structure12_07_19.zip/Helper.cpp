#include<iostream>
using namespace std;
int main()
{
   string str="";
   cout<<str;
    return 0;
}

