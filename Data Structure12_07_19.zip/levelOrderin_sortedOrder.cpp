#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,n,i,j;
    cin>>t;
    while(t--)
    {
        cin>>n;
        int l=0,u=0;
        int A[n+1];
        for(int i=1;i<=n;i++)
        {
            cin>>A[i];
        }
        cout<<A[1]<<endl;
        int f=0;
        for(i=1;u<n;i++)
        {
            l=int(pow(2,i));
            u=int(pow(2,i+1)-1);
            sort(A+l,A+u+1);
            for(j=l;j<=u;j++)
            {
                cout<<A[j]<<" ";
            }
            cout<<endl;

        }
        if(u>n)
        {
        l=int(pow(2,i));
        sort(A+l,A+n+1);
        for(int k=l;k<=n;k++)
            {cout<<A[k]<<"--";
            }
        cout<<endl;
        }


    }
    return 0;
}

