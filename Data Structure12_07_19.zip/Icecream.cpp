#include<iostream>
using  namespace std;
int main()
{
    int t,n,g;
    cin>>t;
    while(t--)
    {
        cin>>n;
        g=(n*(n+1))/2;
        g=g%1000000007;
        cout<<g<<endl;

    }

    return 0;
}
