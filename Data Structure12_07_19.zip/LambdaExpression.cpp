#include<iostream>
#include<algorithm>
using namespace std;
struct DoubleNum
{
  int operator()(int num)
  {
      return num*20;
  }
};
int main()
{
    [](int n){return n*2;};
    int d=(9);
    cout<<d;
  return 0;
}
