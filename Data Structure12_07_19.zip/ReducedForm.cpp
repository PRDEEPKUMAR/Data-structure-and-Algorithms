#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,i,k;
        map<int, int> mp;
        cin>>n;
        int A[n];
        int *B=(int*)calloc(1006,sizeof(int));
        int *C=(int*)calloc(1006,sizeof(int));

        for(i=0;i<n;i++)
        {
            cin>>A[i];
            C[i]=A[i];
        }
       /* for(i=0;i<n;i++)
        {
            cout<<A[i]<<" ";
        }*/
        sort(A, A+n);

        for(i=0;i<n;i++)
        {
            mp.insert(pair<int , int>(A[i],i));
        }

        map<int, int>:: iterator it=mp.begin();
       for(i=0;i<n;i++,it++)
       {
           B[i]=mp.find(C[i])->second;

       }
       for(i=0;i<n;i++)
       {
           cout<<B[i]<<" ";
       }
        cout<<endl;

    }
    return 0;
}
