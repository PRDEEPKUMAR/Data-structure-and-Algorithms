#include<bits/stdc++.h>
using namespace std;
struct Node{
	char data;
	Node *left,*right;
};
Node *newNode(char Data)
{
    Node *new_node = new Node;
    new_node->data = Data;
    new_node->left = new_node->right = NULL;
    return new_node;
}
void preorder(Node *root){
	if(root==NULL)
		return;
	cout<<root->data<<" ";
	preorder(root->left);
	preorder(root->right);
}
Node *convertExpression(string str,int &i);
int main(){
	int t;
	cin>>t;
	while(t--){
		string str;
		cin>>str;
		int i=0;
		Node *root=convertExpression(str,i);
		preorder(root);
		cout<<endl;
	}
}

/*This is a function problem.You only need to complete the function given below*/
/*Complete the function below
Node is as follows
struct Node{
	char data;
	Node *left,*right;
};
*/
Node *convertExpression(string str,int &i)
{
      Node* root;
    if(str.length()==i)
    {
        return NULL;
    }
    if(str[i]!='?'&&str[i]!=':')
    {
        root=newNode(str[i]);
        i++;
    }
    if(str[i]=='?')
    {
        i++;
        root->left=convertExpression(str,i);
    }
    else if(str[i]==':')
    {
        i++;
        root->right=convertExpression(str,i);
    }
    return root;

}
