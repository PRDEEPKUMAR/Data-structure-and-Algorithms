#include<bits/stdc++.h>
using namespace std;
struct Node
{
    int data;
    struct Node* next;
};
void print(struct Node *Node)
{
    while (Node!=NULL)
    {
        cout << Node->data << " ";
        Node = Node->next;
    }
}
struct Node * mergeResult(struct Node *node1,struct Node *node2);
Node *newNode(int data)
{
    Node *temp = new Node;
    temp->data = data;
    temp->next = NULL;
    return temp;
}
int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        int nA;
        cin>>nA;
        int nB;
        cin>>nB;
        struct Node* headA=NULL;
        struct Node* tempA = headA;
        for(int i=0;i<nA;i++)
        {
            int ele;
            cin>>ele;
            if(headA==NULL)
            {
                headA=tempA=newNode(ele);
            }else{
                tempA->next = newNode(ele);
				tempA=tempA->next;
            }
        }
        struct Node* headB=NULL;
        struct Node* tempB = headB;
        for(int i=0;i<nB;i++)
        {
            int ele;
            cin>>ele;
            if(headB==NULL)
            {
                headB=tempB=newNode(ele);
            }else{
                tempB->next = newNode(ele);
				tempB=tempB->next;
            }
        }
        struct Node* result = mergeResult(headA,headB);
        print(result);
        cout<<endl;
    }
}


Node* reverse(Node *head)
{
  Node *p,*q,*r;
  p=NULL;
  q=head;
  r=q->next;
  while(r!=NULL)
  {
      q->next=p;
      p=q;
      q=r;
      r=r->next;
  }
  q->next=p;
  head=q;
  return head;
}
Node* sortedMerge(Node* head1,   Node* head2)
{
    Node* head3=NULL,*last3=NULL,*p1=head1,*p2=head2;
    while(p1&&p2)
    {
        if(head3==NULL)
        {
            if(p1->data>p2->data)
            {
                head3=newNode(p1->data);
                last3=head3;
                p1=p1->next;
            }
            else{
                head3=newNode(p2->data);
                last3=head3;
                p2=p2->next;
            }
        }
        else
        {
            if(p1->data>p2->data)
            {
                last3->next=newNode(p1->data);
                last3=last3->next;
                p1=p1->next;
            }
            else
            {
                last3->next=newNode(p2->data);
                last3=last3->next;
                p2=p2->next;
            }
        }
        if(p1==NULL)
        {
            while(p2!=NULL)
            {
                last3->next=newNode(p2->data);
                last3=last3->next;
                p2=p2->next;
            }
        }
        if(p2==NULL)
        {
            while(p1!=NULL)
            {
                last3->next=newNode(p1->data);
                p1=p1->next;
                last3=last3->next;
            }
        }
    }
    return head3;
}

struct Node * mergeResult(Node *node1,Node *node2)
{
    node1=reverse(node1);
    node2=reverse(node2);
    node1=sortedMerge(node1,node2);
    return node1;
}
