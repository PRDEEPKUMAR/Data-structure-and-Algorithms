#include<iostream>
#include<bits/stdc++.h>
typedef unsigned long long int ulli;
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m,i,max=0;
        cin>>n>>m;
        unsigned long long int  A[n],B[m];
        map<ulli, int> mp;
        map<ulli , int> :: iterator it;
        for(i=0;i<n;i++)
        {
            cin>>A[i];

        }
        for(i=0;i<m;i++)
        {
            cin>>B[i];
            mp.insert(pair<ulli,int>(B[i],i));
        }
        for(i=0;i<n;i++)
        {

            if(mp.find(A[i])==mp.end())
            {
                cout<<A[i]<<" ";
            }
        }

        cout<<endl;
    }
    return 0;
}

