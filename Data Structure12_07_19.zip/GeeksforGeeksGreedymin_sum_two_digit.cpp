#include<iostream>
using namespace std;
void heapify(int A[],int i ,int n)
{
    int t;
    int l=2*i+1;
    int r=2*i+2;
    int lar=i;
    if(A[lar]<A[l]&&l<n)
    {
        lar=l;
    }
        if(A[lar]<A[r]&&r<n)
    {
        lar=r;
    }
    if(lar!=i)
    {
        t=A[lar];
        A[lar]=A[i];
        A[i]=t;
        heapify(A,lar,n);
    }


}
void Build_Max_Heap(int A[],int n)
{
     int i=0;
    for(i=n/2+1;i>=0;i--)
        heapify(A,i,n);

}
void heap_sort(int A[],int n)
{
    int size=n-1;
    int i;
    int temp;

    Build_Max_Heap(A,n);

    for(i=0;i<n;i++)
    {
      temp=A[0];
       A[0]=A[size];
       A[size]=temp;
       Build_Max_Heap(A,size);
       size--;
    }
}
int main()
{
    int t,i,n,f,s;
    int farr[100],sarr[100];
    cin>>t;
    while(t--)
    {
        f=0,s=0;
        cin>>n;
        int A[n];
        for(int i=0;i<n;i++)
        {
            cin>>A[i];

        }
        heap_sort(A,n);
        for(i=0;i<n;i++)
        {
            if(i%2==0)
            {
                f=f*10+A[i];
            }
            else
            {
                s=s*10+A[i];
            }
        }
        cout<<f+s<<endl;

    }

    return 0;
}
