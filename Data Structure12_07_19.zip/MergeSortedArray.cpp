#include<iostream>
#include<bits/stdc++.h>
using namespace std;
void merge(int A[], int x ,int B[],int y)
{
     int i=0,j=0;
    while(i<x&&j<y)
    {
        if(A[i]<=B[j])
        {
            cout<<A[i]<<" ";
            i++;
        }
        else
        {
            cout<<B[j]<<" ";
            j++;
        }
    }
    if(i==x)
    {
        for(int l=j;l<y;l++)
        {
            cout<<B[l]<<" ";
        }
    }
    if(j==y)
    {
        for(int l=i;l<x;l++)
        {
            cout<<A[l]<<" ";
        }
    }
}
int main()
{
    int i,x,y,t;
    cin>>t;
    while(t--)
    {
        cin>>x>>y;
        int *A=(int*)malloc(sizeof(int)*x);
        int *B=(int*)malloc(sizeof(int)*y);
        for(int i=0;i<x;i++)
        {
            cin>>A[i];
        }
        for(int i=0;i<y;i++)
        {
            cin>>B[i];
        }
        merge(A,x,B,y);
    }
    return 0;
}
