#include<iostream>
#include<math.h>
#include<string>
#include<sstream>

using namespace std;
int ex(string str)
{
      string s,out;
    stringstream ss;
    getline(cin,s);
    ss<<s;
    int x;
    while(ss>>out)
    {
        stringstream convert(out);
        convert>>x;

    }

    if(str[0]=='S')
        x=-x;
        cout<<"In ex:"<<x;
    return x;
}
int main()
{
    int t,n,x,i;
    cin>>t;
    string str;
    while(t--)
    {
        cin>>n>>x;
        int init=x;
        for(i=0;i<n;i++)
        {
              string s,out;
        stringstream ss;
        getline(cin,s);
        cin.ignore();
        ss<<s;
        int x;
          while(ss>>out)
          {
          stringstream convert(out);
          convert>>x;

         }

         if(str[0]=='S')
        x=-x;
        cout<<"In ex:"<<x;
        init=init+x;
        }

         if(init>x)
         {
             cout<<"Yes"<<endl;
         }
         else
         {
             cout<<"No"<<endl;
         }

    }
   return 0;
}
