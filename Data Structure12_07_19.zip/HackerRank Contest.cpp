#include<iostream>
using namespace std;
int main() {
   int i,t,j,n,m,c=0,k;
    cin>>t;
    while(t--)
    {
        cin>>n>>m;
        c=0;
        for(i=1;i<n;i++)
        {
            for(j=i+1,k=n;j<=k;j++,k--)
            {
                if(i!=j&&(i+j)%m==0)
                {

                    cout<<i<<"  "<<j<<endl;
                    c++;
                }
                if(i!=k&&(i+k)%m==0)
                {
                    c++;
                    cout<<i<<"  "<<k<<endl;
                }
            }
        }
        cout<<c<<endl;

    }
    return 0;
}
