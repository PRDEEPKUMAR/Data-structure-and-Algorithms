#include <bits/stdc++.h>
using namespace std;
/* A binary tree node has data, pointer to left child
   and a pointer to right child */
struct Node
{
    int data;
    struct Node* left;
    struct Node* right;
};
/* Helper function that allocates a new node with the
   given data and NULL left and right pointers. */
struct Node* newNode(int data)
{
  struct Node* node = (struct Node*)
                       malloc(sizeof(struct Node));
  node->data = data;
  node->left = NULL;
  node->right = NULL;
  return(node);
}
int findDist(Node* ,int ,int );
/* Driver program to test size function*/
int main()
{
  int t;
  struct Node *child;
  scanf("%d", &t);
  while (t--)
  {
     map<int, Node*> m;
     int n;
     scanf("%d",&n);
     struct Node *root = NULL;
     if(n==1)
     {
        int a;
        cin>>a;
        cout<<a<<endl;
     }else{
     while (n--)
     {
        Node *parent;
        char lr;
        int n1, n2;
        scanf("%d %d %c", &n1, &n2, &lr);
      //  cout << n1 << " " << n2 << " " << (char)lr << endl;
        if (m.find(n1) == m.end())
        {
           parent = newNode(n1);
           m[n1] = parent;
           if (root == NULL)
             root = parent;
        }
        else
           parent = m[n1];
        child = newNode(n2);
        if (lr == 'L')
          parent->left = child;
        else
          parent->right = child;
        m[n2]  = child;
     }
     int a,b;
     cin>>a>>b;
     cout<<findDist(root,a,b)<<endl;
  }
  }
  return 0;
}

/*This is a function problem.You only need to complete the function given below*/
/* A binary tree node
struct Node
{
    int data;
    Node* left, * right;
}; */
/* Should return minimum distance between a and b
   in a tree with given root*/
   int storeAllAncestorOfNode(Node* t,int val,vector<int> &v)
{
     int l,r;
    if(t==NULL)
        return 0;
    if(t->data==val)
       {
           v.insert(v.begin(),t->data);
           return 1;
       }
    l=storeAllAncestorOfNode(t->left,val,v);
    r=storeAllAncestorOfNode(t->right,val,v);
    if(l||r)
    {
        if(t)
        v.insert(v.begin(),t->data);
    }
}

int findDist(Node* root, int a, int b)
{
    // Your code here
    vector<int> v1,v2;
    storeAllAncestorOfNode(root,a,v1);
    storeAllAncestorOfNode(root,b,v2);
   /* cout<<"vector: ";
    for(int k=0;k<v2.size();k++)
        cout<<v2[k]<<" ";
        cout<<endl;
          for(int k=0;k<v1.size();k++)
        cout<<v1[k]<<" ";*/
    int i=0;
    if(v1.size()==0)
        return v2.size();
    if(v2.size()==0)
    {
        return v1.size();
    }
    while(v1[i]==v2[i])
    {
        i++;
    }
    int c=(v1.size()-i)+(v2.size()-i);
    return c;

}

