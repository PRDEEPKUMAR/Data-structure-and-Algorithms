///O(n^2) algorithm will not run for input greater 10^5.
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int k,c=0,sum=0,n,i,j;
        cin>>n;
        int A[n];
        for(i=0;i<n;i++)
        {
            cin>>A[i];
        }
        cin>>k;
        for(i=0;i<n;i++)
        {
            sum=0;
            for(j=i;j<n;j++)
            {
                sum=sum+A[j];
                if(sum==k)
                {
                    c++;
                }

            }
        }
        cout<<c<<endl;
    }
    return 0;
}
