#include<iostream>
#include<set>
#include<algorithm>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);

    cin.tie(NULL);
   char str[10000];
    int t,n,x;
    cin>>t;
    while(t--)
    {
        set<int> s;

        cin>>n>>x;
        cin>>str;
        s.insert(x);
        for(int i=0;str[i]!='\0';i++)
        {
            if(str[i]=='L')
            {
                x=x-1;
                s.insert(x);
            }
            else if(str[i]=='R')
            {
                x=x+1;
                s.insert(x);
            }
        }
        cout<<s.size()<<endl;
    }
}
