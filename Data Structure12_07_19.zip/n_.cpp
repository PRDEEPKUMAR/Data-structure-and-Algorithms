#include<iostream>
#include<math.h>
using namespace std;
float nrAlgorithm(float m,float n)
{
    float g=1,x=n/2;
    int i=0;
    while(i<1000)
    {
        x=((m-1)*pow(x,m)+n)/(m*pow(x,m-1));


            g=x;

        i++;

    }
    return g;

}
int main()
{
    float n;
    cin>>n;
    float y=nrAlgorithm(2,n);
    cout<<y;

  return 0;
}
