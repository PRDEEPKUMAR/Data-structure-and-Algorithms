#include<iostream>
using namespace std;
int main()
{
    long int t,n,c,i,pre,next;
    cin>>t;
    while(t--)
    {
        c=2;
        cin>>n;
      long int A[n];
      for(i=0;i<n;i++)
        cin>>A[i];
      for(i=1;i<n-1;i++)
      {
          pre=i-1,next=i+1;

          if((A[i]-A[pre])<0&&(A[next]-A[i]>0))
            c++;
      }
      cout<<c<<endl;

    }
    return 0;
}
