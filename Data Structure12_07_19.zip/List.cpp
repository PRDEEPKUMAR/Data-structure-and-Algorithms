#include<iostream>
#include<algorithm>
#include<list>
#include<vector>
using namespace std;
int main()
{
   vector<int> v1;
   int n,val,i;
   vector<int>::iterator m;
   cin>>n;
   for(int i=0;i<n;i++)
   {
       cin>>val;
       v1.insert(v1.end(),val);
   }
   for(i=0;i<n;i++)
   {

      m= min_element(v1.begin(),v1.end());
      for(int j=0;i<v1.size();j++)
      {
          if(v1[j]!=*m)
          v1[j]=v1[j]-*m;
          else
            std::remove(v1.begin(), v1.end(), *m);
      }
      cout<<v1.size();
   }



  return 0;
}
