#include "Hello.h"

Hello::Hello()
{
    //ctor
}

Hello::~Hello()
{
    //dtor
}
