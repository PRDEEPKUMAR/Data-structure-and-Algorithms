#include<bits/stdc++.h>
using namespace std;
int main()
{
   map<string, int> mp;
   int  i,n;
   string str;
   cin>>n;
   for(i=0;i<n;i++)
   {

       cin>>str;
       mp.insert(pair<string, int>(str,i));
   }
   for(auto it=mp.begin(); it!=mp.end();it++)
   {
       cout<<it->first<<"--"<<it->second<<endl;
   }
    return 0;
}
