#include<iostream>
using namespace std;
int main()
{
  int i,n,m,val;
  int A[10000]={0};
  int B[10000]={0};
  //cout<<"Enter the value of n"<<endl;
  cin>>n;

  for(i=0;i<n;i++)
  {
    cin>>val;
    A[val]++;
  }
  //cout<<"Enter the value of m"<<endl;
  cin>>m;
  for(i=0;i<m;i++)
  {
    cin>>val;
    B[val]++;
  }
  for(i=0;i<10000;i++)
  {
      if(A[i]!=B[i])
        cout<<i<<" ";
  }
  return 0;
}
