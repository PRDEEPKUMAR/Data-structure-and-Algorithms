#include<iostream>
using namespace std;
int main()
{
     cout<<'a'%25;
  return 0;
}
