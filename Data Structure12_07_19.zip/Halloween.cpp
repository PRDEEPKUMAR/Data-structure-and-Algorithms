#include<iostream>
using namespace std;
int main()
{
    int s,p,m,d,count=1,k,sum=0;
    cin>>p>>d>>m>>s;

    sum=s-p;
    while(p>=m)
    {
        p=p-d;
        sum=sum-p;
        count++;
        // cout<<"p"<<p<<endl;

    }
    if(p!=m)
    {

    sum=sum+p;
    --count;
    }
    //cout<<"sum"<<sum<<endl;
    while(sum>0)
    {
        sum=sum-m;
        count++;
    }
    count--;

    cout<<count;
  return 0;
}
