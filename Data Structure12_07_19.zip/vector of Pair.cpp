#include<bits/stdc++.h>
using namespace std;
bool sortbysec(const pair<int,int> &a,const pair<int,int > &b)
{
    return (a.second< b.second);
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    vector<pair<int,int>> v;
    int n,val1,val2;
    cout<<"Enter the size"<<endl;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>val1>>val2;
        v.insert(v.end(),make_pair(val1,val2));
    }
    sort(v.begin(),v.end(),sortbysec);
    for(int i=0;i<v.size();i++)
    {
        cout<<v[i].first<<" "<<v[i].second<<endl;
    }
    return 0;
}
