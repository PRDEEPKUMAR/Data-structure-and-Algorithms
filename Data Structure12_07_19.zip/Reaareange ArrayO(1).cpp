#include<bits/stdc++.h>
using namespace std;
int main()
{

    int test,n,temp;
    int i,k,t;
    int *A=NULL;
    cin>>test;
    while(test--)
    {
        cin>>n;
        A=(int*)malloc(sizeof(int)*n);
        for(i=0;i<n;i++)
        {
            cin>>A[i];
        }
        for(i=0;i<n;i++)
        {
            t=A[i];
            if(t<i)
            {
                k=t;
                while(k<i)
                {

                    k=A[k];
                }
                A[i]=A[k];
                A[k]=t;
            }
            else
            {
                A[i]=A[t];
                A[t]=t;
            }
        }
        for(i=0;i<n;i++)
            cout<<A[i]<<" ";
            cout<<endl;

    }

}
