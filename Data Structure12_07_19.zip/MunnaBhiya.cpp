#include<iostream>
using namespace std;
int main()
{
    int n,f=0,i,m=0,fifty=0,hund=0,twohund=0;
    cin>>n;
    int A[n];
    for(i=0;i<n;i++)
        cin>>A[i];
    for(i=0;i<n;i++)
    {
        if(A[i]==50)
        {
            m=m+50;
            fifty++;
        }
        else if(A[i]==100&&fifty>=1)
        {
            m=m-50;
            m=m+100;
            hund++;
            fifty--;
        }
        else if(A[i]==200&&((fifty>=1&&hund>=1||(fifty>=3))))
            {
            if(fifty>=3)
            {
            fifty=fifty-3;
                m=m-150;
            m=m+200;
            twohund++;
            }
            else if(fifty>=1&&hund>=1)
            {
               fifty--;
               hund--;
            m=m-150;
            m=m+200;
            twohund++;
            }

          }



    }
    if(m==0)
        cout<<"YES"<<"\n";
    else
        cout<<"NO"<<"\n";

    return 0;
}
