#include<iostream>
using namespace std;
int main()
{
    int j,l,r,i,max=0,v;
    cin>>l>>r;
    for(i=l;i<=r;i++)
    {
        for(j=i;j<=r;j++)
        {
            v=i^j;
            if(max<v)
                max=v;
        }
    }
    cout<<max;
    return 0;
}
