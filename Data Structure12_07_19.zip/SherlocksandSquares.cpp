#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    int t;
    int a,b,t1,t2,i,count;
    cin>>t;
    while(t--)
    {
        count=0;
        cin>>a>>b;
        t1=sqrt(a);
        t2=sqrt(b);
        for(i=t1;i<=t2;i++)
        {
            if((i*i)>=a&&(i*i)<=b)
                count++;
        }
        cout<<count<<endl;


    }
  return 0;
}
