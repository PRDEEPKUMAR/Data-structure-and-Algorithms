#include <bits/stdc++.h>
using namespace std;
/* A binary tree node has data, pointer to left child
   and a pointer to right child */
struct Node
{
    int data;
    struct Node* left;
    struct Node* right;

    Node(int x){
        data = x;
        left = right = NULL;
    }
};
int maxDiff(Node *root);
int main()
{
  int t;
  struct Node *child;
  scanf("%d", &t);
  while (t--)
  {
     map<int, Node*> m;
     int n;
     scanf("%d",&n);
     struct Node *root = NULL;

     while (n--)
     {
        Node *parent;
        char lr;
        int n1, n2;
        scanf("%d %d %c", &n1, &n2, &lr);
        if (m.find(n1) == m.end())
          {
           parent = new Node(n1);
           m[n1] = parent;
           if (root == NULL)
             root = parent;
          }
        else
        parent = m[n1];
        child = new Node(n2);
        if (lr == 'L')
          parent->left = child;
        else
          parent->right = child;
        m[n2]  = child;
         }
    cout<<maxDiff(root)<<endl;
 }
  return 0;
}



 /*  int storeAllAncestorOfNode(Node* t,int val,vector<int> &v)
{
     int l,r;
    if(t==NULL)
        return 0;
    if(t->data==val)
       {
           v.insert(v.begin(),t->data);
           return 1;
       }
    l=storeAllAncestorOfNode(t->left,val,v);
    r=storeAllAncestorOfNode(t->right,val,v);
    if(l||r)
    {
        if(t)
        v.insert(v.begin(),t->data);
    }
}
int findMinAncestor(Node* t,int val,int &min)
{
     int l,r;
    if(t==NULL)
        return 0;
    if(t->data==val)
       {
           min=t->data;
           return 1;
       }
    l=findMinAncestor(t->left,val,min);
    r=findMinAncestor(t->right,val,min);
    if(l||r)
    {
        if(t)
        {
            if(t->data<min)
            min=t->data;

        }
    }
}
void maximumDiffernce(Node* root,Node* perRoot, int &max)
{

    if(root==NULL)
        return ;
        int min=999999;
        findMinAncestor(perRoot,root->data,min);
        if(max<(root->data-min))
        {
            max=root->data-min;
        }
    maximumDiffernce(root->left,perRoot,max);
    maximumDiffernce(root->right,perRoot,max);

}
*/
int  returnMax(int *A,int n)
{

    int max=-10000;
    for(int i=n;i>0;i--)
    {
        for(int j=i-1;j>=0;j--)
        {
            //cout<<A[i]<<" :i  j:"<<A[j];
            if(max<(A[j]-A[i]))
            {
                max=A[j]-A[i];
            }
        }
    }
    return max;
}
void   ancestorDiff(Node * root,int A[],int i,int &max)
{
    int temp;
    if(root==NULL)
        return ;
    else if(!root->left&&!root->right)
    {
         A[i]=root->data;
         temp=returnMax(A,i);
         if(max<temp)
         {
             max=temp;
         }
        return ;
    }
    A[i]=root->data;
    ancestorDiff(root->left,A,i+1,max);
    ancestorDiff(root->right,A,i+1,max);


}

int maxDiff(Node* root)
{
    int max=-9999;
    int A[1000]={0};
    ancestorDiff(root,A,0,max);
    return max;



}
///8 3 L 3 1 L 3 6 R 6 4 L 6 7 R 8 10 L 10 13 L 10 14 R
