#include<stdio.h>
#include<bits/stdc++.h>
using namespace std;
struct Graph
{
    int E;
    int V;
    int **adj;
};
Graph* returnAdjMatrixOfGraph()
{
    int u,v;
    int i,j;
    Graph *G=(Graph*)malloc(sizeof(Graph));
    cout<<"Enter number of Edge and Vertices of the Graph "<<endl;
    cin>>G->E>>G->V;
    G->adj=(int**)malloc((G->V+1)*sizeof(int));
    for(i=0;i<=G->V;i++)
    {
        G->adj[i]=(int*)malloc((G->V+1)*sizeof(int));
    }
    for(i=0;i<=G->V;i++)
    {
        for(j=0;j<=G->V;j++)
        {
            G->adj[i][j]=0;
        }
    }
    cout<<"\nEnter the Edges for Non-Directed Graph : ";
    for(i=0;i<G->E;i++)
    {
        cin>>u>>v;
        G->adj[u][v]=1;
        G->adj[v][u]=1;
    }
    return G;

}
void displayAdjMatrix(Graph *G)
{
    int i,j;
    for(i=1;i<=G->V;i++)
    {
        for(j=1;j<=G->V;j++)
        {
            cout<<G->adj[i][j]<<" ";
        }
        cout<<endl;
    }
}
void depthFirstSearch(Graph* G, int start)
{
    int i,j;
    int t;
    stack<int> s;
    int A[G->V+1]={0};
    s.push(start);
    while(!s.empty())
    {
        t=s.top();
        cout<<t<<" ";
        s.pop();
        A[t]=1;
        for(i=1;i<=G->V;i++)
        {
            if(G->adj[t][i]!=0)
            {
                if(A[i]==0)
                s.push(i);
            }
        }
    }
    cout<<endl;

}
void breadthFirstSearch(Graph *G, int start)
{
    queue<int> q;
    int i,t;
    int A[G->V+1]={0};
    q.push(start);
    while(!q.empty())
    {
        t=q.front();
        cout<<t<<" ";
        q.pop();
        A[t]=1;
        for(i=1;i<=G->V;i++)
        {
            if(G->adj[t][i]!=0)
            {
                if(A[i]==0)
                {
                    q.push(i);
                }
            }
        }
    }
    cout<<endl;
}
int main()
{
    int s;
    Graph *G=returnAdjMatrixOfGraph();
   // displayAdjMatrix(G);
    cout<<"Enter the staring Node for Depth First Search :";
    cin>>s;
    cout<<"Depth First Search Traversal :";
    depthFirstSearch(G,s);
    cout<<"Breadth First Search Traversal : ";
    breadthFirstSearch(G,s);

    return 0;
}
