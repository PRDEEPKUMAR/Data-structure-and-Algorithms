#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;
int main()
{
    int t,n,i;
    char str[10000];
    cin>>t;
    while(t--)
    {
        cin>>n;
        cin.ignore();
        cin.get(str,n+1);
        str[n]='\0';
    for(i=0;i<n;i++)
    {
        if(str[i]>='a'&&str[i]<='m')
        {
            str[i]=str[i]+13;
        }
        else if(str[i]>='n'&&str[i]<='z')
        {
            str[i]=str[i]-13;
        }

        else if(str[i]>='A'&&str[i]<='M')
        {
            str[i]=str[i]+13;
        }
        else  if(str[i]>='N'&&str[i]<='Z')
        {
            str[i]=str[i]-13;
        }
        else if(str[i]>='0'&&str[i]<='4')
        {
            str[i]=str[i]+5;
        }
        else if(str[i]>='5'&&str[i]<='9')
        {
            str[i]=str[i]-5;

        }
    }
       //str[n]='\0';
        //for(i=0;i<n;i++)
            puts(str);
            //cout<<"l";
            cout<<endl;
            fflush(stdout);
    }
    return 0;
}

/*



2
9
UryYbPuRs
22
JrYpBzr gb UnPxvAt 552




*/
