#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,n,i,j;
    cin>>t;
    while(t--)
    {
        cin>>n;
        int *A=new int[n+100];
        for(int i=1;i<=n;i++)
        {
            cin>>A[i];
        }
        cout<<A[1]<<endl;
        for(i=2,j=4;j<=n;i=i*2,j=j*2)
        {

            sort(A+i,A+j);
            for(int k=i;k<=j;k++)
            {

                cout<<A[k]<<" ";
            }

            cout<<endl;
        }
        sort(A+i,A+n);
        for(int k=i;k<n;k++)
            cout<<A[k]<<" ";
        cout<<endl;



    }
    return 0;
}
