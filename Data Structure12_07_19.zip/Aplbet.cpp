#include<iostream>
int main()
{
    int t=200,n;
    while(t--)
    {
       cin>>ch
       cout<<ch;
    }
}
