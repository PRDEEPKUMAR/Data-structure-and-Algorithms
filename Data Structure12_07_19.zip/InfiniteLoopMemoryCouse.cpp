#include<iostream>
#include <math.h>
using namespace std;

int main() {
    int val,k,d;
    cin>>val;
    k=log2(val)-1;

    d=(3*pow(2,k));
    if(val==d-2)
    {
        cout<<d;
    }
     else if(val>d-2)
    {
        cout<<d-(val-(d-2));
    }
    else if(val<d-2)
    {

         d=(3*pow(2,k-1));
         cout<<d-(val-(d-2));
    }
      return 0;
}
