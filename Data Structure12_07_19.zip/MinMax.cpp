#include<iostream>
using namespace std;
void find_min_max(int A[],int p,int r,int max,int min)
{
    int q,min1,max1;
    if(p==r)
    {
        min=max=A[p];
    }
    else if(p==r-1)
    {
        if(A[p]>A[r])
        {
            max=A[p];
            min=A[r];

        }
        else
        {
            max=A[r];
            min=A[p];
        }
    }
    else
    {
        q=(p+r)/2;
        find_min_max(A,p,q,min,max);
        find_min_max(A,q+1,r,min1,max1);
        if(min1<min)
            min=min1;
        if(max1>max)
            max=max1;
    }

}
int main()
{
    int A[]={1,2,3,4,5,6,7,8,9,89};
    int min=0,max=0;
    find_min_max(A,0,9,max,min);
    cout<<"Min :- "<<min<<"Max :- "<<max<<endl;
    return 0;
}
