#inlcude<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{

    int t;
    while(t--)
    {
        cin>>n;
        fo

    }
    return 0;
}
