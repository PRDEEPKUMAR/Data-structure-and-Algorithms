#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    pair<int ,string> P1;
    P1.first=10;
    P1.second="Pradeep Kumar";
    cout<<P1.first<<P1.second<<endl;
    return 0;
}
