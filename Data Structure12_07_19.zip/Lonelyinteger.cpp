#include<iostream>
using namespace std;
int main()
{
    int A[100]={0};
    int i,n,val;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>val;
        A[val]++;
    }
    for(int i=0;i<100;i++)
    {
        if(A[i]==1)
        {
            cout<<A[i];
            break;
        }
    }

    return 0;
}
