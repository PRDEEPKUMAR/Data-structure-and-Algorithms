#include<iostream>
using namespace std;
int main()
{
    int t,n,k,g=0,c=0;

    cin>>t;
    while(t--)
    {
        c=0;
        cin>>n;
        k=n;
        while(n>0)
        {

            g=n%10;
            if(g!=0&&k%g==0)
                c++;
            n=n/10;

        }
   cout<<c;
    }

    return 0;

}
