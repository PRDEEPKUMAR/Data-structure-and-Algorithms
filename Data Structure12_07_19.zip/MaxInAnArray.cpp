#include<stdio.h>
#include<stdlib.h>
long int maxVal(long int A[],int pi,int pj)
{

    long int max=-1;
    int i;
    for(i=pi;i<=pj;i++)
    {
        if(max<A[i])
            max=A[i];
    }
    return max;


}
int main()
{
    long int *A=(long int *)malloc(60*sizeof(long int));
    long int n;
    int count =0;
    int i=0,j=3;
    scanf("%ld",&n);
    for(i=0;i<n;i++)
        scanf("%ld",&A[i]);


    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {

            if(A[i]*A[j]<=maxVal(A,i,j))
            {

                count++;
            }
        }
    }
    printf("%d",count);

    return 0;
}
