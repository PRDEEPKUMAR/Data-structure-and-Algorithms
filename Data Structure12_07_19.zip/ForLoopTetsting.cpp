#include<iostream>
using namespace std;
int main()
{
    for(int i=0;i<5;i++)
    {
        cout<<i<<" ";
        i=i+2;
        cout<<i<<"#";
    }
  return 0;
}
