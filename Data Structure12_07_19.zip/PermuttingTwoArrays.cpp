#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int q;
    cin>>q;
    int k,n,val;
    while(q--)
    {
        int f=0;
        vector<int> A,B;
        cin>>n>>k;
        for(int i=0;i<n;i++)
        {
            cin>>val;
            A.insert(A.end(),val);
        }
        for(int i=0;i<n;i++)
        {
            cin>>val;
            B.insert(B.end(),val);
        }
        sort(A.begin(),A.end());
        sort(B.begin(),B.end(),greater<int>());
        for(int i=0,j=n-1;i<j;i++,j--)
        {
            if(A[i]+B[i]<k||A[j]+B[j]<k)
            {
                f=1;
            }

        }
        if(f==0)
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;



    }
}
