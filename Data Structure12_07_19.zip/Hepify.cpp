#include<stdio.h>
void heapify(int A[],int i ,int n)
{
    int t;
    int l=2*i+1;
    int r=2*i+2;
    int lar=i;
    if(A[lar]<A[l]&&l<n)
    {
        lar=l;
    }
        if(A[lar]<A[r]&&r<n)
    {
        lar=r;
    }
    if(lar!=i)
    {
        t=A[lar];
        A[lar]=A[i];
        A[i]=t;
        heapify(A,lar,n);
    }


}
void Build_Max_Heap(int A[],int n)
{
     int i=0;
    for(i=n/2+1;i>=0;i--)
        heapify(A,i,n);

}


int main()
{
    int i=0;
    int A[10]={10 , 50 ,170,5,990};
    heapify(A,i,5);

    printf("%d",A[0]);

    return 0;
}

