#include <stdio.h>
#include<stdlib.h>
int randomiser=0;
int* arr;
void generate(int n)
{
 randomiser++;
 srand(n+randomiser);
 free(arr);
 arr=(int*)malloc(n*sizeof(int));
 for(int i=0;i<n;i++)
  *(arr+i)=rand();
}
void swap(int* x,int* y)
{
	int t=(*x);
	(*x)=(*y);
	(*y)=t;
}
void display(int n)// display
{
 int i;
 for (i=0;i<n;i++)
  printf("%d  ",*(arr+i));
}
// To heapify a subtree rooted with node i which is
// an index in arr[]. n is size of heap
void heapifysmall(int arr[], int n, int i)
{
	int smallest = i; // Initialize smalles as root
	int l = 2 * i + 1; // left = 2*i + 1
	int r = 2 * i + 2; // right = 2*i + 2

	// If left child is smaller than root
	if (l < n && arr[l] < arr[smallest])
		smallest = l;

	// If right child is smaller than smallest so far
	if (r < n && arr[r] < arr[smallest])
		smallest = r;

	// If smallest is not root
	if (smallest != i) {
		swap(&arr[i],&arr[smallest]);

		// Recursively heapify the affected sub-tree
		heapifysmall(arr, n, smallest);
	}
}
// main function to do heap sort
void maxheapSort(int arr[], int n)
{
	// Build heap (rearrange array)
	for (int i = n / 2 - 1; i >= 0; i--)
		heapifysmall(arr, n, i);

	// One by one extract an element from heap
	for (int i = n - 1; i >= 0; i--) {
		// Move current root to end
		swap(&arr[0],&arr[i]);

		// call max heapify on the reduced heap
		heapifysmall(arr, i, 0);
	}
}
// Prototype of a utility function to swap two integers
void swap(int *x, int *y);
	int *harr; // pointer to array of elements in heap
	int capacity; // maximum possible size of max heap
	int heap_size; // Current number of elements in max heap
	void MinHeap(int a[], int size); // Constructor
	void minHeapify(int i); //To maxHeapify subtree rooted with index i
	int parent(int i) { return (i-1)/2; }
	int left(int i) { return (2*i + 1); }
	int right(int i) { return (2*i + 2); }
	int extractMax(); // extracts root (maximum) element
	int getMin() { return harr[0]; } // Returns maximum
	// to replace root with new node x and heapify() new root
	void replaceMin(int x) { harr[0] = x; minHeapify(0); }

void MinHeap(int a[], int size)
{
	heap_size = size;
	harr = a; // store address of array
	int i = (heap_size - 1)/2;
	while (i >= 0)
	{
		minHeapify(i);
		i--;
	}
}

// Method to remove maximum element (or root) from max heap
int extractMin()
{
	if (heap_size == 0)
		return (+2147483647);

	// Store the maximum vakue.
	int root = harr[0];

	// If there are more than 1 items, move the last item to root
	// and call heapify.
	if (heap_size > 1)
	{
		harr[0] = harr[heap_size-1];
		minHeapify(0);
	}
	heap_size--;

	return root;
}

// A recursive method to heapify a subtree with root at given index
// This method assumes that the subtrees are already heapified
void minHeapify(int i)
{
	int l = left(i);
	int r = right(i);
	int largest = i;
	if (l < heap_size && harr[l] < harr[i])
		largest = l;
	if (r < heap_size && harr[r] < harr[largest])
		largest = r;
	if (largest != i)
	{
		swap(&harr[i], &harr[largest]);
		minHeapify(largest);
	}
}
// Function to return k'th largest element in a given array
int kthSmallest(int arr[], int n, int k)
{
	// Build a heap of first k elements: O(k) time
	MinHeap(arr, k);

	// Process remaining n-k elements. If current element is
	// smaller than root, replace root with current element
	for (int i=k; i<n; i++)
		if (arr[i] > getMin())
		   replaceMin(arr[i]);

	// Return root
	return (getMin());
}
void descend(int start,int end)//descending order
{
 if(start==end-1)
  {
   if(*(arr+start)<*(arr+end))
    {
     int temp=*(arr+start);
     *(arr+start)=*(arr+end);
     *(arr+end)=temp;
    }
   }
 else if(start==end)
	{}
 else
  {
   int temp[end-start+1];
   int i=0,l=start,m=((end+start)/2)+1,k=0;
   descend(start,(end+start)/2);
   descend(((end+start)/2)+1,end);
   for(l=start,m=((end+start)/2)+1;(l<=(end+start)/2)&&(m<=end);i++)
    {
     if(*(arr+l)<=*(arr+m))
      {
       temp[i]=*(arr+m);
       m++;
      }
     else
      {
       temp[i]=*(arr+l);
       l++;
      }
    }
   for(l=l;l<=(end+start)/2;l++,i++)
    {
     temp[i]=*(arr+l);
    }
   for(m=m;m<=end;m++,i++)
    {
     temp[i]=*(arr+m);
    }
   for(k=0,l=start;k<=i&&l<=end;k++,l++)
    *(arr+l)=temp[k];
  }
}
int partition(int arr[], int l, int r)
{
	int x = arr[r], i = l;
	for (int j = l; j <= r - 1; j++)
	{
		if (arr[j] >= x)
		{
			swap(&arr[i], &arr[j]);
			i++;
		}
	}
	swap(&arr[i], &arr[r]);
	return i;
}
int kthSmallestquick(int arr[], int l, int r, int k)
{
	// If k is smaller than number of elements in array
	if (k > 0 && k <= r - l + 1)
	{
		// Partition the array around last element and get
		// position of pivot element in sorted array
		int pos = partition(arr, l, r);

		// If position is same as k
		if (pos-l == k-1)
			return arr[pos];
		if (pos-l > k-1) // If position is more, recur for left subarray
			return kthSmallestquick(arr, l, pos-1, k);

		// Else recur for right subarray
		return kthSmallestquick(arr, pos+1, r, k-pos+l-1);
	}

	// If k is more than number of elements in array
	return (+2147483647);
}
int main()
{
	int n,k;
	arr=(int*)malloc(10000000*sizeof(int));
	printf("\nEnter number of elements:");
	scanf("%d",&n);
	generate(n);
	printf("\nEnter value of k:");
	scanf("%d",&k);
	display(n);
	maxheapSort(arr,n);
	printf("\nIn O(n+klogn):%d",*(arr+k-1));
    generate(n);
	display(n);
    descend(0,n-1);
    printf("\nIn O(nlogn):%d",*(arr+k-1));
    generate(n);
	display(n);
    printf("\nIn O(k+(n-k)*logk):%d",kthSmallest(arr, n, k));
	generate(n);
	display(n);
	printf("\nIn O(nk):%d",kthSmallestquick(arr, 0, n-1, k));
	printf("\n");
	return 0;
}
