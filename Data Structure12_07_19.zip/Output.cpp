#include<iostream>
using namespace std;
int main()
{
  int a=5;
  int *p=&a;
  for(int i=0;i<100;i++)
  {
      cout<<(int)*(p++)<<"  ";
  }
   return 0;
}
