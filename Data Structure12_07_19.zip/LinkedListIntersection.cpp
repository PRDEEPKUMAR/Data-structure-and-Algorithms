#include<bits/stdc++.h>
using namespace std;
struct node
{
	int data;
	struct node* next;
};
void printList(struct node *node)
{
    while(node!=NULL){
        cout<<node->data<<' ';
        node = node->next;
    }
    printf(" ");
}
void push(struct node** head_ref, int new_data)
{
    struct node* new_node =	(struct node*) malloc(sizeof(struct node));
    new_node->data = new_data;
    new_node->next = (*head_ref);
    (*head_ref) = new_node;
}
struct node* findIntersection(struct node* head1, struct node* head2);
int main()
{
    long test;
    cin>>test;
    while(test--)
    {
        struct node* a = NULL;
        struct node* b = NULL;
        int n, m, tmp;
        cin>>n;
        for(int i=0; i<n; i++)
        {
            cin>>tmp;
            push(&a, tmp);
        }
        cin>>m;
        for(int i=0; i<m; i++)
        {
            cin>>tmp;
            push(&b, tmp);
        }
        printList(findIntersection(a, b));
    }
    return 0;
}


/*This is a function problem.You only need to complete the function given below*/
/*
structure of the node is as
struct node
{
	int data;
	struct node* next;
};
*/

typedef struct node Node;
Node* newNode(int data)
{
    Node* temp=new Node;
    temp->data=data;
    temp->next=NULL;
    return temp;
}
struct node* findIntersection(struct node* head1, struct node* head2)
{

    Node* p=head1,*q=head2;
    Node* head3=NULL,*last3=NULL;
    vector<int> s1,s2;
    vector<int> ::iterator last;
    vector<int> v;
    while(p!=NULL)
    {
        s1.insert(s1.end(),p->data);
        p=p->next;
    }
    while(q!=NULL)
    {
        s2.insert(s1.end(),q->data);
        q=q->next;
    }
    sort(s1.begin(),s1.end());
    sort(s2.begin(),s2.end());
    last=set_intersection(s1.begin(),s1.end(),s2.begin(),s2.end(),v.begin());

    for(auto it=v.begin();it!=last;it++)
    {
        if(head3==NULL)
        {
            head3=newNode(*it);
            last3=head3;
        }
        else
        {
            last3->next=newNode(*it);
            last3=last3->next;
        }
    }
    cout<<"Hello Worldend"<<endl;
    return head3;
}
