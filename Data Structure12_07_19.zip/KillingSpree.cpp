#include<iostream>
using namespace std;
int main()
{

    unsigned long long int t,p,g=0;
    int i,k;
    cin>>t;
    while(t--)
    {
        cin>>p;
        i=1;
        k=0;
        g=0;
        while(g<p)
        {
            g=(i*(i+1)*(2*i+1))/6;
            i=i*2;
            k++;
        }

    }
    return 0;
}
