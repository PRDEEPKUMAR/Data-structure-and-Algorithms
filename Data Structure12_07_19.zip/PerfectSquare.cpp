#include <bits/stdc++.h>
using namespace std;

bool isPerfectSquare(long double x)
{

  long double sr = sqrt(x);
  return ((sr - floor(sr)) == 0);
}

int main() {
   long int t,n,a,b;
    cin>>t;
        while(t--)
        {
            cin>>a>>b;
            n=(a*a)+(b*b);
            if (isPerfectSquare(n))
              cout << "yes"<<endl;
            else
              cout << "no"<<endl;
        }
    return 0;
}
