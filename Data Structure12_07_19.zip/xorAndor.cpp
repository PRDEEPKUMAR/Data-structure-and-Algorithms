#include<iostream>
using namespace std;
int main()
{
    int n,i,s=0,max=0;
    cin>>n;
    int A[n];
    for(i=0;i<n;i++)
    {
        cin>>A[i];
    }
    for(i=0;i<n;i++)
    {
        for(int j=i+1;j<n-i-1;j++)
        {
                 s=(((A[i]&A[j])^(A[i]|A[j]))&(A[i]^A[j]));
               if(max<s)
                max=s;
        }
    }
    cout<<max;

    return 0;
}
