#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,i,val;
        cin>>n;
        int S[n],F[n];
         vector<pair<int,int>> vp;
        for(i=0;i<n;i++)
        {
            cin>>S[i];
        }
        for(i=0;i<n;i++)
        {
            cin>>F[i];
            vp.insert(vp.end(),pair<int , int >(F[i],i));
        }
        sort(vp.begin(),vp.end());
        int j;
        vector<pair<int, int>> res;
        for(i=0,j=0;i<n;i++)
        {
            if(i==0)
            {
                 res.insert(res.end(),pair<int,int>(S[vp[0].second],F[vp[0].second]));
                cout<<vp[i].second+1<<" ";
                j++;
            }
           else if(S[vp[i].second]>=res[j-1].second)
            {
                res.insert(res.end(),pair<int,int>(S[vp[i].second],F[vp[i].second]));
                cout<<vp[i].second+1<<" ";
                j++;
            }

        }
        cout<<endl;
    }
    return 0;
}
