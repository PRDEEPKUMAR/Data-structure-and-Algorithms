#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include<set>
#include <algorithm>
using namespace std;


int main() {
    set<int> S;
    int n,t;
    for(int i=0;i<n;i++)
    {
        cin>>t;
        S.insert(t);
    }



    return 0;
}
