#include<iostream>
using namespace std;
int fun1(int n)
{
    int i,j,k=0,l=0;
    for(i=n;i>=1;i=i/2)
       {
        for(j=1;j<=i;j++)
        {
          k=k+1/n;
        }
       }
    return k;
}
int main()
{
  cout<<fun1(1);
    return 0;
}
