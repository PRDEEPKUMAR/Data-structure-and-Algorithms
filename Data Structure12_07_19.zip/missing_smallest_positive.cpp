#include<iostream>
using namespace std;
int main()
{

    int B[100000]={0};
    int i,t,n;
    cin>>t;
    while(t--)
    {
    cin>>n;
    int A[n+1];
    for(i=0;i<n;i++)
    {
        cin>>A[i];
        if(A[i]>=0)
        {
            B[A[i]]=1;
        }
    }
    i=1;
    while(B[i]!=0)
    {
        i++;
    }
    cout<<i<<endl;
    }
   return 0;
}
