#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    multimap<int , int > m1;
    m1.insert(pair<int , int >(-1,20));
    m1.insert(pair<int , int >(-1,30));

    cout<<"Traversing the map"<<endl;
    cout<<"First    Second"<<endl;
    for(auto ite=m1.begin();ite!=m1.end();ite++)
    {
        cout<<ite->first<<"        "<<ite->second<<endl;
    }
    return 0;
}
