#include<iostream>
#include<bits/stdc++.h>
using namespace std;
void reverse(char* str)
{

    int i,j,n,size=1,k;
    char *str2=new char[2001];
    int A[100]={0};
    for(i=0;i<=strlen(str);i++)
    {
        if(str[i]=='.'||str[i]=='\0')
        {
            A[size]=i;
            size++;
        }
    }
    str[strlen(str)]='.';
    str[strlen(str)+1]='\0';
    int g=0;
    for(i=0;i<size;i++)
    {
        cout<<A[i]<<" ";
    }
    cout<<endl;
    for(k=size-1;k>0;k--)
    {
        for(i=A[k]+1;i<=A[k+1];i++)
        {
            //cout<<str[i];
            str2[g++]=str[i];
        }
    }
     for(i=A[k];i<A[k+1];i++)
        {
            //cout<<str[i];
            str2[g++]=str[i];
        }

    cout<<str2<<endl;
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        char str[2001];
        cin>>str;
        reverse(str);

    }
    return 0;
}
