#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
  int n,i=0,s=0,j=0,y=0;
  int start;
  cin>>n;
  int P[n],D[n],diff[n];
  for(int i=0;i<n;i++)
  {
     cin>>P[i]>>D[i];
     diff[i]=P[i]-D[i];
  }
        y=diff[0];
        int f=0;
  for(i=0;i<n;i++)
  {
      y=diff[i];j=i;
      while(y>=0)
      {
          j++;
          y=y+diff[(j)%n];
          if(i==(j%n))
          {
              f=1;
              break;
          }
      }
      if(f==1)
      {
          cout<<i;
          break;
      }


  }
  //cout<<j;


 return 0;
}
/*
5
1 10
2 20
3 30
4 40
1000 50
*/
