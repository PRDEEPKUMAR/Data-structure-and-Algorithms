#include<iostream>
using namespace std;
int main()
{
    int t,n,A[100]={0},H[101]={0},max=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>t;
        H[t]++;
    }
    for(int i=0;i<100;i++)
       if(max<(H[i]+H[i+1]))
            max=H[i]+H[i+1];

        cout<<max;

    return 0;
}
