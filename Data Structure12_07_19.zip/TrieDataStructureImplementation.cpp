#include<iostream>
#include<bits/stdc++.h>
# define ALPHA 26
using namespace std;
struct TrieNode
{

    TrieNode* children[ALPHA];
    bool isEndOfTheWord;
};
TrieNode* getNode()
{
    TrieNode* p=new TrieNode;
    int i;
    for(i=0;i<ALPHA;i++)
    {
        p->children[i]=NULL;
    }
    p->isEndOfTheWord=false;

}
void insertIntoTrie(TrieNode*&root,string key)
{
    struct TrieNode* p=root;
    int i;
    for(i=0;i<key.length();i++)
    {
       // cout<<p<<endl;
        int index=key[i]-'a';
        if(!p->children[index])
        {
          p->children[index]=getNode();
        }
        p=p->children[index];
    }
    p->isEndOfTheWord=true;
}
bool searchInTrie(TrieNode* root,string key)
{
    struct TrieNode* p=root;
    int i;
    for(i=0;i<key.length();i++)
    {
       // cout<<p<<endl;
        int index=key[i]-'a';
        if(!p->children[index])
            {
                return false;
            }
        p=p->children[index];
    }
    //cout<<p<<endl;
    return  (p!=NULL&&p->isEndOfTheWord);
}
bool isEmpty(TrieNode *root)
{
    int i;
    for(i=0;i<ALPHA;i++)
    {
        if(!root->children[i])
            return false;
    }
    return true;
}
TrieNode* deleteFromTrie(TrieNode *root, string key,int depth=0)
{
    if(!root)
        return NULL;
    if(depth==key.size())
    {

        if(root->isEndOfTheWord==true)
        {
            root->isEndOfTheWord=false;
        }
        if(isEmpty(root))
        {
            delete(root);
            root=NULL;

        }
        return root;
    }
    int index=key[depth]-'a';
    root->children[index]=deleteFromTrie(root->children[index],key,depth+1);
    if(isEmpty(root)&&root->isEndOfTheWord==false)
    {
        delete(root);
        root=NULL;
    }
    return root;
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,i;
        cin>>n;
        struct TrieNode *root=getNode();
        string A[n],key;
        for(i=0;i<n;i++)
        {
            cin>>A[i];
        }
        cin>>key;
        for(i=0;i<n;i++)
        {
            insertIntoTrie(root,A[i]);
        }
        deleteFromTrie(root,key);
        cout<<searchInTrie(root,key);

    }
    return 0;
}
