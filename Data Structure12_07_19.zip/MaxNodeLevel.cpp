
#include<bits/stdc++.h>
using namespace std;
struct Node{
	int data;
	Node *left,*right;
};
Node *newNode(int data)
{
    Node* temp = new Node;
    temp->data = data;
    temp->left = NULL;
    temp->right = NULL;

    return (temp);
}
void insert(Node *root,int a1,int a2,char lr){
	if(root==NULL){
		return;
	}
	if(root->data==a1){
		switch(lr){
			case 'L':root->left=newNode(a2);
			break;
			case 'R':root->right=newNode(a2);
			break;
		}
	}
	else{
		insert(root->left,a1,a2,lr);
		insert(root->right,a1,a2,lr);
	}
}
void inorder(Node *root){
	if(root==NULL)
		return;
	inorder(root->left);
	cout<<root->data<<" ";
	inorder(root->right);
}
int maxNodeLevel(Node *root1);
int main()
{
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	int t;
	cin>>t;
	while(t-->0)
	{
		int n;
		cin>>n;
		int m=n;
		Node *root1=NULL;
		while(n-->0){
			int a1,a2;
			cin>>a1>>a2;
			char lr;
			scanf(" %c",&lr);
			if(root1==NULL){
				root1=newNode(a1);
				switch(lr){
					case 'L':root1->left=newNode(a2);
					break;
					case 'R':root1->right=newNode(a2);
					break;
				}
			}
			else{
				insert(root1,a1,a2,lr);
			}
		}
			cout<<maxNodeLevel(root1)<<" ";
	}
}

/*This is a function problem.You only need to complete the function given below*/
/*Complete the function below
Node is as follows:
struct Node{
	int data;
	Node *left,*right;
};
*/
int  max_level_in_BT(Node * t)
{
    int i=0,level=0;
    int max=0,sum=0;
    queue<Node*> q;
    Node* temp;
    q.push(t);
    q.push(NULL);
    int count=0;
    while(!q.empty())
    {
        temp=q.front();
        if(temp!=NULL)
        {
           sum++;
        }
        q.pop();
        if(temp==NULL&&q.front()==NULL)
        {
            if(max<sum)
                {
                    max=sum;
                    level=i;
                }
            return level;
        }
        else if(temp==NULL)
        {
            q.push(NULL);
            if(max<sum)
               {
                   level=i;
                   max=sum;
               }
            sum=0;
            i++;

        }
        else
        {
            if(temp->left)
                q.push(temp->left);
            if(temp->right)
                q.push(temp->right);
        }
    }


}
int maxNodeLevel(Node *root)
{
    return max_level_in_BT(root);
}
