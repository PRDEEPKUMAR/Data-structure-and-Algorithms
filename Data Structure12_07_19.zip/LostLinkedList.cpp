#include<iostream>
using namespace std;
int main()
{
    int *a,b=1234321;
    a=&b;
    int *p;
    while(p!=a)
    {
        p++;
        cout<<p<<" ";

    }
    cout<<*p;
    return 0;

}
