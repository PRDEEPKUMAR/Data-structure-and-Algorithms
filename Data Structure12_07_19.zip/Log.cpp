#include<iostream>
#include <math.h>
using namespace std;

int main() {
    int val,k,d;
   // cin>>val;
    k=log2(10000);
cout<<k;
    return 0;
}
