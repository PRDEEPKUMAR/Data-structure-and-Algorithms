#include <stdio.h>
void sort(int L[],int n)
{
 int temp;
 for(int i=0;i<n;i++)
	for(int j=i+1;j<n;j++)
		if(L[i]>L[j])
			{
				temp=L[i];
				L[i]=L[j];
				L[j]=temp;
			}
}
void findOrderMRT(int L[], int n)
{
	sort(L,n);
	printf("Optimal order in which programs are to be"
			"stored is: ");
	for (int i = 0; i < n; i++)
		printf("%d ",L[i]);
	printf("\n");;
	double MRT = 0;
	for (int i = 0; i < n; i++) {
		int sum = 0;
		for (int j = 0; j <= i; j++)
			sum += L[j];
		MRT += sum;
	}
	MRT /= n;
	printf("Minimum Retrieval Time of this order is %lf",MRT);
}
int main()
{
	int n;
	printf("\nEnter number of programs:");
	scanf("%d",&n);
	int L[n];
	printf("\nEnter lengths:");
	for(int i=0;i<n;i++)
	 scanf("%d",&L[i]);
	findOrderMRT(L, n);
	return 0;
}
