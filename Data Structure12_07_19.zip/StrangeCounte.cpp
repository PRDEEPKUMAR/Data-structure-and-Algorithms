#include<iostream>
using namespace std;
int main()
{
  int t, d = 0, k = 3, count = 3, val;
  cin >> val;
  while (count < val) {
    k = 2 * k;
    count = count + k;
  }
  count = count + 1;
  k = k * 2;
  // cout<<count<<k<<endl<<endl;
  if (val > k) {
    d = val - count;
    cout << k - d;
    // cout<<"k is more";

  } else {
    d = count - val;
    cout << d;
  }

  return 0;
}
