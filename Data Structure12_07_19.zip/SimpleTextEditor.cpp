#include<iostream>
#include<string>
using namespace std;
int main()
{
    int t,q,l,k;
    string st[10000];
    string current="";
    string  temp;
    int top=-1;
    cin>>t;
    while(t--)
    {
        cin>>q;
        if(q==1)
        {
            st[++top]=current;
            cin>>temp;
            current.append(temp);


        }
        else if(q==2)
        {
            cin>>k;
            st[++top]=current;
            l=current.length();
            current.erase(l-k,l);
        }
        else if(q==3)
        {
            cin>>k;
            cout<<current[k-1];
        }
        else if(q==4)
        {
            current=st[top--];
        }
    }

    return 0;
}

