#include<iostream>
using namespace std;
int main()
{
    int t,f;
    cin>>t;
    while(t--)
    {
    int n,i,g;
    cin>>n>>g;
    int A[n+1];
    int cur_sum=0,start=1;
    for(i=1;i<=n;i++)
    {
        cin>>A[i];
    }
     f=0;
    for(i=1;i<=n;i++)
    {
        if(cur_sum<g)
        {
            //cout<<"chota ";
            cur_sum=cur_sum+A[i];
            cout<<cur_sum<<endl;
        }
        else if(cur_sum>g)
        {
           // cout<<"bada";
            while(cur_sum>g&&start<=i)
            {
                cur_sum=cur_sum-A[start];
                start++;
                cout<<cur_sum<<endl;

            }
            i--;
        }
        if(cur_sum==g)
        {

            f=1;
            cout<<start<<" "<<i-1<<endl;
            break;

        }
    }
    if(f==0)
    {
        cout<<-1;
    }

    }
    return 0;
}
