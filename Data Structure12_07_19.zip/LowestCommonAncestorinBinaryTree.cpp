///Got Accepted in Geeks for Geeks;
#include <bits/stdc++.h>
using namespace std;
/* A binary tree node has data, pointer to left child
   and a pointer to right child */
struct Node
{
    int data;
    struct Node* left;
    struct Node* right;

    Node(int x){
        data = x;
        left = right = NULL;
    }
};
Node * lca(Node* ,int ,int );
/* Helper function that allocates a new node with the
   given data and NULL left and right pointers. */
/* Driver program to test size function*/
int main()
{
  int t;
  struct Node *child;
  scanf("%d", &t);
  while (t--)
  {
     map<int, Node*> m;
     int n;
     scanf("%d",&n);
     struct Node *root = NULL;
     if(n==1)
     {
        int a;
        cin>>a;
        cout<<a<<endl;
     }else{
     while (n--)
     {
        Node *parent;
        char lr;
        int n1, n2;
        scanf("%d %d %c", &n1, &n2, &lr);
        if (m.find(n1) == m.end())
        {
           parent = new Node(n1);
           m[n1] = parent;
           if (root == NULL)
             root = parent;
        }
        else
           parent = m[n1];
        child = new Node(n2);
        if (lr == 'L')
          parent->left = child;
        else
          parent->right = child;
        m[n2]  = child;
     }
     int a,b;
     cin>>a>>b;
     Node * k = lca(root,a,b);
     cout<<k->data<<endl;
  }
  }
  return 0;
}


/*This is a function problem.You only need to complete the function given below*/
/* A binary tree node
struct Node
{
    int data;
    struct Node* left;
    struct Node* right;

    Node(int x){
        data = x;
        left = right = NULL;
    }
};
 */
/* If n1 and n2 are present, return pointer
   to LCA. If both are not present, return
   NULL. Else if left subtree contains any
   of them return pointer to left.*/

int storeAllAncestor(Node* t, int data,vector<Node*> &v)
{
    int l=1,r=1;
    if(t!=NULL)
    {
        if(t->data==data)
        {
            v.insert(v.end(),t);
            return 1;

        }
       l= storeAllAncestor(t->left,data,v);
       r= storeAllAncestor(t->right,data,v);
        if(l||r)
        {
            if(t)
            v.insert(v.begin(),t);
            return 1;
        }
    }
    return 0;
}
Node* LCA(Node *root, int n1, int n2)
{
    vector<Node*> v1,v2;
    storeAllAncestor(root,n1,v1);
    storeAllAncestor(root,n2,v2);
    int i=0;
    Node *l=root;
    for(i=0;i<v1.size()&&i<v2.size();i++)
    {
        if(v1[i]->data==v2[i]->data)
        {
            l=v1[i];
        }
        else{
            break;
        }
    }
    return l;

   /* if(v1.size()==0&&v1.size()==0)
    return root;
    else if(v1.size()==0)
    {
        return root;
    }
    else if(v2.size()==0)
    {
        return root;
    }
    else
    {
    while(v1[i]==v2[i])
    {
        l=v1[i];
        i++;
    }
    return l;
    }*/
}
Node * lca(Node* root ,int n1 ,int n2 )
{
    return LCA(root,n1,n2);
}
