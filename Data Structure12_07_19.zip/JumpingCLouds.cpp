#include <iostream>
using namespace std;
int main() {
  int count = 0, n, A[1000]={1}, i;
  cin >> n;
  for (i = 0; i < n; i++) {
    cin >> A[i];
  }
  i = 0;
  while (i < n) {
        if(i==n-1)
        {
            break;
        }
    if (A[i + 2] == 0) {
      i = i + 2;
      count++;
    } else if (A[i + 2] == 1)

    {
      i=i+1;
      count++;
    }

  }
  cout << count;

  return 0;
}
