#include<iostream>
using namespace std;
int main()
{
    int x=4;
    int *p=&x;
    switch(x)
    {
        case 1: cout<<"Hello";
                break;
        case 4: cout<<"Mr ";
                break;
    }
    return 0;
}
