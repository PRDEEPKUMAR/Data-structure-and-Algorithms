#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<vector>
using namespace std;
void del(vector<int> *v,int *A,int n)
{
    int i;
    for(i=0;i<n;i++)
    {
       (*v).erase((*v).begin+A[i]);
    }
}
int main()
{
    vector<int> v;
    int I[10000];
    int val,i,n,f=1,k,count=0;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>val;
        v.insert(v.end(),val);
    }
    do
    {
     for(i=0,k=0;i<n;i++)
    {

        if(v[i+1]>v[i])
            I[k++]=i+1;
    }
      del(&v,I,k);
    count++;
    }
    while(f==1);



    return 0;
}
