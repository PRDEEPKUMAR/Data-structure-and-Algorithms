#include<iostream>
using namespace std;
int main()
{
    int d=0,a=5,i=1,sum=0;
    int A[101];
    A[0]=0;
    for(i=1;i<100;i++)
    {
        A[i]=a/2;
        a=(a/2)*3;
    }
    cin>>d;
    for(i=0;i<=d;i++)
        sum=sum+A[i];
        cout<<sum;
    return 0;
}
