#include<stdio.h>
#include<stdlib.h>
#include<time.h>
clock_t start,end;
double cpu_time_used;
int *arr;
int n;
int randomiser=0;
int comp=0;
struct pair
{
int min;
int max;
}minmax;
void generate(int x)
{
 n=x;
 randomiser++;
 srand(n+randomiser);
 free(arr);
 arr=(int*)malloc(n*sizeof(int));
 for(int i=0;i<n;i++)
  *(arr+i)=rand();
}
void iterative(int x)//iterative method
{
 int i=0,check[2]={*(arr),*(arr)};
 for(i=1;i<n;i++)
 {
  if(*(arr+i)<check[0])
			check[0]=*(arr+i);
  comp++;
  if(*(arr+i)>check[1])
			check[1]=*(arr+i);
  comp++;
 }
 if(x==1)
	printf("\nMin=%d Max=%d",check[0],check[1]);
}
struct pair getMinMax(int low, int high)
{
struct pair minmax, mml, mmr;
int mid;

/* If there is only on element */
if (low == high)
{
	minmax.max = *(arr+low);
	minmax.min = *(arr+low);
	return minmax;
}

/* If there are two elements */
if (high == low + 1)
{
	if (*(arr+low) > *(arr+high))
	{
		minmax.max = *(arr+low);
		minmax.min = *(arr+high);
        comp++;
	}
	else
	{
		minmax.max = *(arr+high);
		minmax.min = *(arr+low);
        comp++;
	}
	return minmax;
}

/* If there are more than 2 elements */
mid = (low + high)/2;
mml = getMinMax(low, mid);
mmr = getMinMax(mid+1, high);

/* compare minimums of two parts*/
if (mml.min < mmr.min)
	minmax.min = mml.min;
else
	minmax.min = mmr.min;
comp++;
/* compare maximums of two parts*/
if (mml.max > mmr.max)
	minmax.max = mml.max;
else
	minmax.max = mmr.max;
comp++;
return minmax;
}
int bestcase()
{
 comp=0;
 iterative(0);
 return(comp);
}
double worstcase()
{
 comp=0;
 getMinMax(0,n-1);
 return(comp);
}
void totalcase()
{
 int best,worst;
 printf("\nInput\tIterative\tDivide and conquer\tBetter?\n");
 for(int i=5000;i<=50000;i=i+5000)
 {
  generate(i);
  printf("\n%d",i);
  printf("\t");
  best=bestcase();
  printf("%d",best);
  printf("\t\t");
  worst=worstcase();
  printf("%d",worst);
  printf("\t\t\t");
  if(best<worst)
	printf("I");
  else
	printf("D");
  printf("\n");
 }
}
void display()// display
{
 int i;
 for (i=0;i<n;i++)
  printf("\n%d",*(arr+i));
}
int main()//main function and menu driven part
{
 arr=(int*)malloc(10000*sizeof(int));
 int opt,x;
 printf("\nEnter number of elements:");
 scanf("%d",&x);
 generate(x);
 menu:
 printf("\n1.Generate\n2.Display\n3.Iterative method\n4.Divide and conquer\n5.Compare\n9.exit\nEnter your choice:");
 scanf("%d",&opt);
 switch(opt)
 {
  case 1:
		 printf("\nEnter the number of elements:");
                 scanf("%d",&x);
                 generate(x);
		 break;
  case 2:
		 display();
		 break;
  case 3:
		 iterative(1);
		 break;
  case 4:
		 minmax=getMinMax(0, n-1);
         printf("\nnMinimum element is %d", minmax.min);
         printf("\nnMaximum element is %d", minmax.max);
		 break;
  case 5:
		 totalcase();
		 break;
  case 9:
		 return 0;
		 break;
  default:
		  printf("\nWrong option entered");
		  break;
 }
 goto menu;
}
