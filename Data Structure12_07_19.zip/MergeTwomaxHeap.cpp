#include<iostream>
#include<bits/stdc++.h>
using namespace std;
void mergeTwoMaxHeap(priority_queue<int> p1,priority_queue<int> p2, priority_queue<int> &p3 )
{
    int val1,val2;
    while(!p1.empty()&&!p2.empty())
    {

        val1=p1.top();
        p1.pop();
        val2=p2.top();
        p2.pop();
        if(val1>val2)
        {
            p3.push(val1);
            p3.push(val2);
        }
        else
        {
             p3.push(val2);
            p3.push(val1);

        }

    }
    if(!p1.empty())
    {
        while(!p1.empty())
        {
            p3.push(p1.top());
            p1.pop();
        }
    }
    if(!p2.empty())
    {
        while(!p2.empty())
        {
            p3.push(p2.top());
            p2.pop();
        }
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m,i,val;
        priority_queue<int > p1,p2,p3;
        cin>>n>>m;
        for(i=0;i<n;i++)
        {
            cin>>val;
            p1.push(val);
        }
        for(i=0;i<m;i++)
        {
            cin>>val;
            p2.push(val);
        }
        mergeTwoMaxHeap(p1,p2,p3);
        while(!p3.empty())
        {
            cout<<p3.top()<<" ";
            p3.pop();
        }

    }
    return 0;
}
