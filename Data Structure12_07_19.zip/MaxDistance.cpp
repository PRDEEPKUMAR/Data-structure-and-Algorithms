#include<bits/stdc++.h>
using namespace std;
int maxDistance(int arr[], int n);
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        int arr[n];
        for(int i=0; i<n; i++)
            cin>>arr[i];
        cout<<maxDistance(arr,n)<<endl;
    }
    return 0;
}

/*This is a function problem.You only need to complete the function given below*/
// your task is to complete this function
int maxDistance(int arr[], int n)
{
    int i;
    int B[n+1]={0};
    int max=0,max2=0;
    for(i=0;i<n;i++)
    {
        B[i+1]=arr[i];
        if(max<arr[i])
            max=arr[i];

    }
   // cout<<endl;

    int *A=(int*)calloc(max+100,sizeof(int));
    for(i=1;i<=n;i++)
    {
        A[i]=0;
        //cout<<A[B[i]]<<" ";
        if(A[B[i]]==0)
        {
            A[B[i]]=i;
        }
        else
        {
            A[B[i]]=i-A[B[i]];
        }
    }
    for(i=1;i<=max;i++)
    {
        if(max2<A[i])
            max2=A[i];

    }
    return max2;
}
