#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m,i,max=0;
        cin>>n>>m;
        int A[n],B[m];
        int * C=(int*)calloc(1000000,sizeof(int));
        for(i=0;i<n;i++)
        {
            cin>>A[i];
            C[A[i]]++;
            if(max<A[i])
                max=A[i];

        }
        for(i=0;i<m;i++)
        {
            cin>>B[i];
            if(C[B[i]]!=0)
            {
                C[B[i]]++;
            }
        }
        for(i=0;i<=max;i++)
        {
            if(C[i]==1)
            {
                cout<<i<<" ";
            }
        }
        cout<<endl;
    }
    return 0;
}
