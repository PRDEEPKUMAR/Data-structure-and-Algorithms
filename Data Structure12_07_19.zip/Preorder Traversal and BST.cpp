#include<bits/stdc++.h>
using namespace std;
int nextGreaterElement(int A[],int l, int n)
{
    int i=0;
    for(i=l+1;i<n;i++)
    {
        if(A[i]>A[l])
            return i;

    }
}
bool check(int A[], int next, int n,int l)
{

    int i;
    for(i=next;i<n;i++)
    {
        if(A[i]<A[l])
        {

            return false;
        }
    }
    return true;
}
int main()
{
    int t,n;
    cin>>t;
    while(t--)
    {
        int f=0;
        cin>>n;
        int A[n];
        for(int i=0;i<n;i++)
        {
            cin>>A[i];
        }
        for(int i=0;i<n;i++)
        {
            int next=nextGreaterElement(A,i,n);
            bool chk=check(A,next,n,i);
            if(chk==false)
            {
                f=1;
                break;
            }

        }
        if(f==0)
            cout<<1;
        else if(f==1)
            cout<<0;
        cout<<endl;

    }
    return 0;
}
