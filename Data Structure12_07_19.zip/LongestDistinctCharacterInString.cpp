#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    cin.ignore();
    while(t--)
    {
        string str;
        int max=0,i;
        unordered_map<char, int> mp;
        getline(cin,str);
        for(i=0;i<str.length();i++)
        {
            if(mp.find(str[i])==mp.end())
            {
                mp.insert(pair<char, int >(str[i],i));
            }
            else
            {
                if(max<mp.size())
                    max=mp.size();
                i=mp.find(str[i])->second;
                mp.clear();

            }
        }
        if(max<mp.size())
        max=mp.size();
        cout<<max<<endl;
    }
    return 0;
}
