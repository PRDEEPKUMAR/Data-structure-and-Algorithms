#include <bits/stdc++.h>
using namespace std;
// A Linked List node
struct Node
{
	int data;
	Node* next;
};
Node* mergeKLists(Node* arr[], int N);
/* Function to print nodes in a given linked list */
void printList(Node* node)
{
	while (node != NULL)
	{
		printf("%d ", node->data);
		node = node->next;
	}
	cout<<endl;
}
// Utility function to create a new node.
Node *newNode(int data)
{
	struct Node *temp = new Node;
	temp->data = data;
	temp->next = NULL;
	return temp;
}
// Driver program to test above functions
int main()
{
   int t;
   cin>>t;
   while(t--)
   {
	   int N;
	   cin>>N;
       struct Node *arr[N];
       for(int j=0;j<N;j++)
        {
           int n;
           cin>>n;
           int x;
           cin>>x;
           arr[j]=newNode(x);
           Node *curr = arr[j];
           n--;
           for(int i=0;i<n;i++)
           {
               cin>>x;
               Node *temp = newNode(x);
               curr->next =temp;
               curr=temp;
           }
   		}
   		Node *res = mergeKLists(arr,N);
		printList(res);
   }
	return 0;
}

Node* sortedMerge(Node* head1,   Node* head2)
{
     Node* head3=NULL,*last3=NULL,*p1=head1,*p2=head2;
    while(p1&&p2)
    {
        if(head3==NULL)
        {
            if(p1->data<p2->data)
            {
                head3=newNode(p1->data);
                last3=head3;
                p1=p1->next;
            }
            else{
                head3=newNode(p2->data);
                last3=head3;
                p2=p2->next;
            }
        }
        else
        {
            if(p1->data<p2->data)
            {
                last3->next=newNode(p1->data);
                last3=last3->next;
                p1=p1->next;
            }
            else
            {
                last3->next=newNode(p2->data);
                last3=last3->next;
                p2=p2->next;
            }
        }
        if(p1==NULL)
        {
            while(p2!=NULL)
            {
                last3->next=newNode(p2->data);
                last3=last3->next;
                p2=p2->next;
            }
        }
        if(p2==NULL)
        {
            while(p1!=NULL)
            {
                last3->next=newNode(p1->data);
                p1=p1->next;
                last3=last3->next;
            }
        }
    }
    return head3;
}

Node * mergeKLists(Node *arr[], int N)
{
       int i;
       for(i=0;i<N-1;i++)
       {
           arr[i+1]=sortedMerge(arr[i],arr[i+1]);
       }
       return arr[N-1];
}
