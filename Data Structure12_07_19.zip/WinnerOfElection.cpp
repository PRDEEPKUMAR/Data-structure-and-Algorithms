#include <iostream>
#include <map>
#include <algorithm>
#include <cstdlib>
#include<bits/stdc++.h>
using namespace std;
void winner(string arr[],int n);
int main()
{
    int t;
    cin>>t;

    for(int i=0;i<t;i++)
    {


        int n;
        cin>>n;

        string arr[n];

        for (int i=0;i<n;i++)
        cin>>arr[i];

        winner(arr,n);

        cout<<endl;


    }
    return 0;
}
void winner(string arr[],int n)
{
    map<string, int> mp;
    int A[n]={0},max=-1,maxIndex=-1;
    int i,count=0;
    for(i=0;i<n;i++)
    {
        if(mp.find(arr[i])==mp.end())
        {

            mp.insert(pair<string,int>(arr[i],count));

            count++;
        }
    }


    for(i=0;i<n;i++)
    {
        auto it1=mp.find(arr[i]);
        if(it1!=mp.end())
        {
            A[it1->second]++;
        }
    }
    for(i=0;i<n;i++)
    {
        if(max<A[i])
            {max=A[i];
            maxIndex=i;
            }
       // cout<<A[i]<<" ";
    }
   // cout<<max<<" ";
    auto it=mp.begin();
    for(it=mp.begin();it!=mp.end();it++)
    {
        if(it->second==maxIndex)
        {
            cout<<it->first<<" "<<A[it->second];
            break;
        }
    }
}
