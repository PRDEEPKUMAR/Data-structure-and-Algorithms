#include<iostream>
using namespace std;
int main()
{
    char str1[101],stack[101];
    int top=-1;
    int i=1,k,f=1;
    cin>>str1;
    stack[++top]=str1[0];
    while(str1[i]!='\0')
    {
      if(stack[top]!=str1[i])
      {
          stack[++top]=str1[i];
      }
      else
      {
          top--;

      }
      i++;
    }
    if(top==-1)
        cout<<"Empty String";
    else
    {
    for(i=0;i<=top;i++)
        cout<<stack[i];
    }
  return 0;
}
