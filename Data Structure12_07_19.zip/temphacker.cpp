#include <bits/stdc++.h>
#include <iostream>
using namespace std;
int main()
{
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  long long i,k, n, val;
  vector<long long> v;
  cin >> n >> k;
  for (int i = 0; i < n; i++) {
    cin >> val;
    v.insert(v.end(), val);
  }
  sort(v.begin(), v.end());
  long long min, max, z, ans = 9999999999;
  for ( i = 0; i <=n-k; i++) {
    min = v[i];
    max =v[(i+k-1)];
    z = max - min;
    if (z < ans) {
      ans = z;
    }
  }
    max=v[n-1];
  min=v[(n-1+k)%n];
  if(max-min<ans)
    ans=max-min;
  cout << ans << endl;
  return 0;
}
