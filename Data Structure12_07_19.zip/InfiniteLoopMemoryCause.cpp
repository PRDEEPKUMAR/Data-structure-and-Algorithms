#include<iostream>
using namespace std;

int main() {
    long int *p;
    while(1)
    {
    p=new long int ;
    }


  return 0;
}
