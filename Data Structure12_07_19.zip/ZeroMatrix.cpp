#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{

    int A[100][100];
    int P[15][2];
    int i,j,k=0,l,n,test,t=1;
    scanf("%d",&test);
    while(t<=test)
    {
    scanf("%d",&n);
     for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&A[i][j]);
        }
    }

    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(A[i][j]==0)
            {
                P[k][0]=i;
                P[k][1]=j;
                k++;
            }
        }
    }

   for(l=0;l<k;l++)
   {
       for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                if(i==P[l][0]||j==P[l][1])
                {
                    A[i][j]=0;
                }
            }
        }
    }
      for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("%d ",A[i][j]);
        }

    }
    t++;
}
    return 0;

}
