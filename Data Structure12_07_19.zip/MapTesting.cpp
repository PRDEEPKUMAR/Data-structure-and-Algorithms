#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    map<int, int> mp;
    mp.insert(pair<int, int>(1,10));
    mp.insert(pair<int, int>(1,12));
    for(auto it=mp.begin();it!=mp.end();it++)
    {
        cout<<it->second;
    }

    return 0;
}
/*
1
28
1 1 5 2 7 6 1 4 2 3 2 2 1 6 8 5 7 6 1 8 9 2 7 9 5 4 3 1
