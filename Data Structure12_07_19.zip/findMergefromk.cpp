void merge(int A[],int beg,int mid,int end)
{
 int *T=(int *)malloc(sizeof(int)*10000),k=0;
 int index=beg;
 int i=beg;
 int j=mid+1;
 while((i<=mid)&&(j<=end))
 {
     if(A[i]<A[j])
     {
         T[index]=A[i];
         i++;
     }
     else
     {
         T[index]=A[j];
         j++;
     }
     index++;
 }
 if(i>mid)
 {
      while(j<=end)
     {
         T[index]=A[j];
         j++;
         index++;
     }

 }
 else
 {
      while(i<=mid)
     {
         T[index]=A[i];
         i++;
         index++;
     }
 }
 for(k=beg;k<index;k++)
 {
     A[k]=T[k];
 }
}
