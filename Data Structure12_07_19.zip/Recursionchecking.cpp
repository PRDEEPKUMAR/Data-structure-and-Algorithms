#include<iostream>
using namespace std;
int fun1(int n)
{
    int f;
    if(n==1)
    {
     return 99;
    }
    f=fun1(n-1);

    return f;
}
int main()
{
    cout<<fun1(5);

  return 0;
}
