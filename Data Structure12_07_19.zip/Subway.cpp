#include<iostream>
using namespace std;
int  main()
{
    int t,n,l,b,i,min=99;
    cin>>t;
    while(t--)
    {
        min=99;
        cin>>l>>b;



        for(i=1;i<=(l>b?l:b);i++)
        {
            if((l*b)%(i*i)==0)
                {
                   // cout<<i<<endl;
                    min=((l*b)/(i*i));
                }
        }
            cout<<min<<endl;
        }


    return 0;
}
