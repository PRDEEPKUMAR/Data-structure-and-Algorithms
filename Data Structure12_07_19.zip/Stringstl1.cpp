#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
string intersection(string s1,string s2)
{
    int i=0,j=0,k=0;
    char s3[2000];
    sort(s1.begin(),s1.end());
    sort(s2.begin(),s2.end());

    while(s1[i]!='\0'&&s2[j]!='\0')
    {
        if(s1[i]<s2[j])
            i++;
        else if(s1[i]>s2[j])
            j++;
        else //(s1[i]==s2[j])
        {
            s3[k]=s1[i];
            k++;
            j++;
            i++;
        }
    }
    //
    s3[k]='\0';
    //cout<<s3;
    return s3;

}
using namespace std;
int main()
{
 int i,t,n;
 string temp;

   cin>>t;
   while(t--)
   {
        string temp;
       cin>>n;
       string str[n+1];
       for(i=0;i<n;i++)
       {
           cin>>str[i];
       }
       if(n>1)
       {

       temp=str[0];
       for(i=0;i<n-1;i++)
       {
           temp=intersection(temp,str[i+1]);

       }

       temp.erase(unique(temp.begin(), temp.end()), temp.end());
       //cout<<temp;
       cout<<temp.length()<<endl;
       }
       else
        {
            temp=str[0];
            temp.erase(unique(temp.begin(), temp.end()), temp.end());
              cout<<temp.length()<<endl;
        }
   }

 return 0;
}
