#include<iostream>
using namespace  std;
int find_range(int A[],int low,int high)
{
    int max=-1;
    for(int i=low;i<high;i++)
    {
        if(max<A[i])
            max=A[i];

    }
    return max;
}
int main()
{
    int n,i,j,q,d;
    cin>>n>>q;
    int A[n],Q[q]
    for(i=0;i<n;i++)
        cin>>A[i];
    for(i=0;i<q;i++)
        cin>>Q[i];


    return 0;
}
