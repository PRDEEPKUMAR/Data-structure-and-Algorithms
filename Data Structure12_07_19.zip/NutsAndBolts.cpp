#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    char str[]={'!','#','$','%','&','*','@','^','~'};
    map<char, int> charMap;
    for(int  i=0;i<9;i++)
    {
        charMap.insert(pair<char, int>(str[i],i));
    }
    cin>>t;
    while(t--)
    {
        int n ,i;
        char ch;
        cin>>n;
        int  A[n+1],B[n+1];
        for(i=0;i<n;i++)
        {
            cin>>ch;
            //if(charMap.find(ch)!=charMap.end())
            A[i]=charMap.find(ch)->second;
            //cout<<A[i]<<" ";

        }
        for(i=0;i<n;i++)
        {
            cin>>ch;
            //if(charMap.find(ch)!=charMap.end())
            B[i]=charMap.find(ch)->second;
        }
        sort(A,A+n);
        sort(B,B+n);
        for(i=0;i<n;i++)
        {
            cout<<str[A[i]]<<" ";
        }
        cout<<endl;
        for(i=0;i<n;i++)
        {
            cout<<str[B[i]]<<" ";
        }
    }
    return 0;
}
