
#include<iostream>
#include<bits/stdc++.h>
using namespace std;

 int main()
 {
        ios_base::sync_with_stdio(false);
    cin.tie(NULL);
     int t,n,k,i;
     cin>>t;
     while(t--)
     {
         priority_queue<int, vector<int>, greater<int> > pq;
         cin>>k>>n;
         int A[n];
         for(i=0;i<n;i++)
         {
             cin>>A[i];
             if(i<k-1)
             {
                 cout<<-1<<" ";
                 pq.push(A[i]);
             }
             else
             {
                if(A[i]>=pq.top())
                 {
                     pq.push(A[i]);
                 }
                     cout<<pq.top()<<" ";


             }
         }
         cout<<endl;
     }

   return 0;
 }
