#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
 string temp;
 cin>>temp;
 temp.erase(unique(temp.begin(), temp.end()), temp.end());
 cout<<temp.length();
 cout<<temp;
}
