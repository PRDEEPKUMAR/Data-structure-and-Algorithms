#include<bits/stdc++.h>
using namespace std;

long long int  fact(int n)
{
     long long int f=1;
     for(int i=1;i<=n;i++)
     {
         f=f*i;
     }
     return f;
}

int main()
{
    int t,n ;
    cin>>t;
    unsigned long long int  g=1,sum=0;
    int k,i=0;
    while(t--)
    {
        sum=0;
        g=1;
        i=0;
        cin>>n;
        while(g)
        {
            g=(long long int)fact(n-i)/(fact(i)*fact(n-(2*i)));
            sum=sum+g;
            i++;
        }
        cout<<sum%1000000007<<endl;
    }
    return 0;
}
