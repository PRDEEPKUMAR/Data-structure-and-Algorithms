#include <stdio.h>
#include <stdlib.h>
#include<bits/stdc++.h>
using namespace std;
/* A binary tree Node has data, pointer to left child
and a pointer to right child */
struct Node
{
	int key;
	struct Node* left, *right;
};
int counter=0;
int target=0;
struct Node *ptr=NULL;
// create new Node and initialize it
struct Node* newNode(int key)
{
	struct Node* n = (struct Node*)
					malloc(sizeof(struct Node*));
	if (n != NULL)
	{
		n->key = key;
		n->left = NULL;
		n->right = NULL;
		return n;
	}
	else
	{
		printf("Memory allocation failed!");
		exit(1);
	}
}
// recursive function to find mirror of Node
int findMirrorRec(int target, struct Node* left,
							struct Node* right);
// interface for mirror search
int findMirror(struct Node* root, int target)
{
	if (root == NULL)
		return 0;
	if (root->key == target)
		return target;
	return findMirrorRec(target, root->left, root->right);
}
 void insert(struct Node *root,int n1,int n2,char lr)
 {
     if(root==NULL)
        return;
     if(root->key==n1)
     {
         switch(lr)
         {
          case 'L': root->left=newNode(n2);
                    break;
          case 'R': root->right=newNode(n2);
                    break;
         }
     }
     else
     {
         insert(root->left,n1,n2,lr);
         insert(root->right,n1,n2,lr);
     }
 }
 /*void Inorder(struct Node* root)
{
    if(counter==0)
    {
        cin>>target;
        counter++;
    }
    if(root==NULL)
        return ;
    Inorder(root->left);
    if(root->key==target)
         ptr=root;
    Inorder(root->right);
}*/
// Driver program to test above functions
int main()
{
    /* Let us construct the tree shown in above diagram */
    int t,k;
    cin>>t;
    while(t--)
    {
    int n;
    cin>>n;
    struct Node *root=NULL;
    while(n--)
    {
        char lr;
        int n1,n2;
        cin>>n1>>n2;
        cin>>lr;
        if(root==NULL)
        {
            root=newNode(n1);
            switch(lr){
                    case 'L': root->left=newNode(n2);
                    break;
                    case 'R': root->right=newNode(n2);
                    break;
                    }
        }
        else
        {
            insert(root,n1,n2,lr);
        }
    }
   // Inorder(root);
    //Node * target =ptr;
    //printkdistanceNode(root, target, k);
    //cout<<endl;
    cin>>target;
    counter=0;
    int mirror = findMirror(root, target);
	if (mirror)
		printf("%d",mirror);
	else
		printf("-1");
    }
    return 0;
}

int find_Node(int target, struct Node* left,struct Node* right,int &val)
{
       if(!left||!right)
       {
           return -1;
       }
       if(target==left->key)
        {
            return right->key;
        }
        if(target==right->key)
       {
           return left->key;
       }
       int m=find_Node(target,left->left,right->right,val);
       //if(m!=-1)
       // return m;
       find_Node(target,left->right,right->left,val);
}
int findMirrorRec(int target, struct Node* left,
							struct Node* right)
{
    int val=0;
    return find_Node(target,left,right,val);

}
