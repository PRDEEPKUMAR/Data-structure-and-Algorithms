#include<iostream>
#include<bits/stdc++.h>
#define range(i,n) for(i=0;i<n;i++)
using namespace std;

int main()
{
    int i,n,k,val,sum=0;
 priority_queue<int> q;
 cin>>n>>k;
 int A[n]={0};
 range(i,n)
 {
     cin>>val;
     q.push(val);
 }
 for(i=0;i<n;i++)
 {
     val=q.top();
     q.pop();
     A[i%k]++;
     sum=sum+A[i%k]*val;
 }
cout<<sum<<endl;
 return 0;
}
