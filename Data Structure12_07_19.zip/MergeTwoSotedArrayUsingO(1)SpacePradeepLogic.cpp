#include<iostream>
#include<bits/stdc++.h>
using namespace std;
void Sort(vector<int> &A,int val)
{
    int i,j;
    for(i=1;i<A.size()-1;i++)
    {
        j=i;
        while(j>=0&&A[j]>val)
        {
            A[j+1]=A[j];
            i--;
        }
        A[j]=val;
    }
}
void mergeWithoutSpace(vector<int> &A,vector<int> &B)
{
    int i,j,temp;
    for(i=0;i<A.size();i++)
    {
        if(A[i]>B[1])
        {
        temp=A[i];
        A[i]=B[1];
        B.erase(B.begin());
        Sort(B,A[i]);
        }
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        vector<int> A,B;
        int val,i,n,m;
        cin>>n>>m;
        for(i=0;i<n;i++)
        {
            cin>>val;
            A.insert(A.begin(),val);
        }
        for(i=0;i<m;i++)
        {
            cin>>val;
            B.insert(B.begin(),val);
        }
        mergeWithoutSpace(A,B);
         for(i=0;i<n;i++)
        {
            cout<<A[i]<<" ";
        }
        for(i=0;i<m;i++)
        {
            cout<<B[i]<<" ";
        }
    }
    return 0;
}
