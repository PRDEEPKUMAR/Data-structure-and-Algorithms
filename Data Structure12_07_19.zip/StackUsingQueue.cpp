#include<bits/stdc++.h>
using namespace std;
class QueueStack{
private:
    queue<int> q1;
    queue<int> q2;
public:
    void push(int);
    int pop();
};
int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        QueueStack *qs = new QueueStack();
        int Q;
        cin>>Q;
        while(Q--){
        int QueryType=0;
        cin>>QueryType;
        if(QueryType==1)
        {
            int a;
            cin>>a;
            qs->push(a);
        }else if(QueryType==2){
            cout<<qs->pop()<<" ";
        }
        }
        cout<<endl;
    }
}


/*This is a function problem.You only need to complete the function given below*/
/* The structure of the class is
class QueueStack{
private:
    queue<int> q1;
    queue<int> q2;
public:
    void push(int);
    int pop();
};
 */
/* The method push to push element into the stack */
void QueueStack :: push(int x)
{
    if(q1.empty()&&q2.empty())
    {
        q1.push(x);
    }
    else if(!q1.empty())
    {
        q1.push(x);

    }
    else if(!q2.empty())
    {
        q2.push(x);
    }
}
int QueueStack :: pop()
{
    int temp;
    if(q1.empty()&&q2.empty())
    {
        return -1;
    }
    else if(!q1.empty())
    {
        int i=0;
        while(!q1.empty()&&i<q1.size()-1)
        {
            q2.push(q1.front());
            q1.pop();
            i++;
        }
        temp=q1.front();
        q1.pop();
        return temp;

    }
    else if(!q2.empty())
    {
        int i=0;
        while(!q2.empty()&&i<q2.size()-1)
        {
            q1.push(q2.front());
            q2.pop();
            i++;
        }
        temp=q2.front();
        q2.pop();
        return temp;
    }
}
