#include<iostream>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m,i,j;
        cin>>m>>n;
        int A[n];
        for(i=0;i<n;i++)
            cin>>A[i];
         for(i=0;i<n-1;i++)
         {
             for(j=i+1;j<n;j++)
             {
                 if(A[i]+A[j]==m)
                    cout<<i+1<<" "<<j+1;
             }
         }
    }

    return 0;
}
