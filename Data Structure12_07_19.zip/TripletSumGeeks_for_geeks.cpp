#include<iostream>
using namespace std;
int main()
{
    int n,s;
    int t;
    while(t--)
    {
    cin>>n>>s;
    int A[n];
    for(int i=0;i<n;i++)
    {
        cin>>A[i];
    }
    int i,j,k;
    int count=0;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            for(k=0;k<n;k++)
            {
                if(A[i]+A[j]+A[k]==s)
                    count++;
            }
        }
    }
    cout<<count<<endl;
    }
    return 0;
}
