#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int findkMax(priority_queue<int> &pq,int k)
{

    int A[pq.size()];
    int i,j,temp;
    if(pq.size()<k)
    {
        return -1;
    }
    else
    {

        for(i=0;i<k-1;i++)
        {
            A[i]=pq.top();
            pq.pop();
        }
        temp=pq.top();
        //cout<<" temp :-" <<temp;
        for(j=0;j<i;j++)
        {
            pq.push(A[j]);
        }
    }
    return temp;
}
 int main()
 {
        ios_base::sync_with_stdio(false);
    cin.tie(NULL);
     int t,n,k,i;
     cin>>t;
     while(t--)
     {
         priority_queue<int > pq;
         cin>>k>>n;
         int A[n];
         for(i=0;i<n;i++)
         {
             cin>>A[i];
             pq.push(A[i]);
             cout<<findkMax(pq,k)<<" ";
         }
         cout<<endl;
     }

   return 0;
 }
