#include<iostream>
using namespace std;
int main()
{
long  t,n,f,i=1;
  cin>>t;
  while(t--)
  {
  f=1;
    cin>>n;
    for(i=1;i<=n;i++)
    {
    f=f*i;
    }
    cout<<f<<endl;
  }

   return 0;
}
