#include"iostream"
#include"fuck.cpp"
#define START main
#include<stdio.h>

using namespace std;
namespace pradeep
{

    void fun1()
    {

        cout<<"Pradeep Kumar "<<endl;
    }
}
using namespace pradeep;
int execute()
{
    fun1();
    cout<<" Hi";
}
