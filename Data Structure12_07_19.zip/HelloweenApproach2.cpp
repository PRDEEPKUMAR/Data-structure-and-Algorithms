#include<iostream>
using namespace std;
int main()
{
    int s,p,m,d,count=0,k,sum=0;
    cin>>p>>d>>m>>s;
    while(sum<s)
    {
        if(p>=m)
        {
        sum=sum+p;
        p=p-d;
        count++;
        }
        else
        {
            sum=sum+m;
            count++;
        }

    }


    cout<<count-1;
  return 0;
}
