#include <iostream>
using namespace std;
int rem(int A[], int n) {

  int i, k, B[n];
  B[0] = A[0];
  for (i = 1, k = 1; i < n; i++) {
    if (B[i - 1] > A[i]) {
      B[k] = A[i];
      k++;
    }
  }
  for (i = 0; i < k; i++)
    A[i] = B[i];
  return k;
}
int check(int A[], int n) {
  int f = 0, i;
  for (i = 0; i < n - 1; i++) {
    if (A[i + 1] > A[i]) {
      f = 1;
      break;
    }
  }
  if (f == 1)
    return 1;
  else
    return 0;
}
int main() {
  int n, i, siz, count = 0, f = 0;
  cin >> n;
  int A[n];
  for (i = 0; i < n; i++)
    cin >> A[i];
  siz = n;
  f = check(A, n);
  while (f == 1) {
    siz = rem(A, siz);
    count++;
    f = check(A, siz);
  }
  cout << count;

  return 0;
}
