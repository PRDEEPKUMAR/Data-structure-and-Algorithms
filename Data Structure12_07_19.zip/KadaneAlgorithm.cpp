``#include<iostream>
using namespace std;
int KadaneAlgorithm(int A[], int n)
{
    int max_so_far=-999999;
    int max_ending_here=0;
    for(int i=0;i<n;i++)
    {
        max_ending_here=max_ending_here+A[i];
        if(max_so_far<max_ending_here)
            max_so_far=max_ending_here;
        if(max_ending_here<0)
            max_ending_here=0;
    }
    return max_so_far;
}
int main()
{
    int t,n;
    uniq
    cin>>t;
    while(t--)
    {
        cin>>n;
        int A[n];
        for(int i=0;i<n;i++)
        {
            cin>>A[i];
        }
        cout<<KadaneAlgorithm(A,n)<<endl;
    }
    return 0;
}
