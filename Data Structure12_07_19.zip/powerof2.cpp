#include<iostream>
#include<bits/stdc++.h>
typedef unsigned long long int ulli;
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        ulli n;
        cin>>n;
        ulli g=(ulli)(pow(2,18))%n;
        if(%n==0)
            cout<<"YES";
        else
            cout<<"NO";
    }
    return 0;
}
