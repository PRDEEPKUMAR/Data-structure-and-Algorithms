#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        long int n,i,j;
        long int sum=0;
        long int count =0;
        unordered_map<long int,long int> mp;
         cin>>n;
        int A[n];

        for(i=0;i<n;i++)
            {
                cin>>A[i];
            }
        for(i=0;i<n;i++)
        {
            sum=sum+A[i];
            cout<<sum<<"-- ";
            if(mp.find(sum)!=mp.end())
            {
                count++;
            }
            mp.insert(pair<long int,long int>(sum,i));
            if(i!=0&&i!=n-1)
            {
                if(A[i]==0)
                  count++;
            }
        }
         cout<<count<<endl;

    }
     return 0;
}
