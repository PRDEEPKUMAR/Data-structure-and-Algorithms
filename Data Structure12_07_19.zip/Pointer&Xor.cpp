#include<iostream>
using namespace std;
int main()
{

    int a,b;
    int c,d;
    a=&c;
    b=&d;

    return 0;
}
