#include <bits/stdc++.h>
using namespace std;



int main()
{
    int t,n,l=0;
    cin>>t;
    while(t--)
    {
        char str[100000];
        cin>>n;
        cin>>str;
        for(int i=0;str[i]!='\0';i++)
        {
            if(str[i]=='E')
            {
                str[i]='S';

            }
            else if(str[i]=='S')
            {
                str[i]='E';
            }
        }
        cout<<"Case #"<<l<<": "<<str<<endl;
        l++;
    }
    return 0;
}
