#include<stdio.h>
#include<stdlib.h>
#include<iostream>
using namespace std;
/* Linked list Node */
struct Node
{
    int data;
    struct Node* next;
};
 void reorderList(struct Node* head) ;
/* Function to create a new Node with given data */
struct Node *newNode(int data)
{
    struct Node *new_Node = (struct Node *) malloc(sizeof(struct Node));
    new_Node->data = data;
    new_Node->next = NULL;
    return new_Node;
}
void printList(struct Node *Node)
{
    while(Node != NULL)
    {
        printf("%d ", Node->data);
        Node = Node->next;
    }
    printf(" ");
}
void freeList(struct Node *head)
{
	struct Node* temp;
    while(head != NULL)
    {

        temp=head;
        head = head->next;
        free(temp);
    }

}
int main(void)
{
   int t,n,m,i,x;
   cin>>t;
   while(t--)
   {
	   struct Node* temp,*head;
	    cin>>n;
	    cin>>x;
	    head=newNode(x);
	    temp=head;
	    for(i=0;i<n-1;i++)
	    {
			cin>>x;
			temp->next=newNode(x);
			temp=temp->next;
			}

		reorderList(head);
	    printList(head);
freeList(head);
   }
   return 0;
}
Node* reverse(Node *head)
{
  Node *p,*q,*r;
  p=NULL;
  q=head;
  r=q->next;
  while(r!=NULL)
  {
      q->next=p;
      p=q;
      q=r;
      r=r->next;
  }
  q->next=p;
  head=q;
  return head;
}
void breakLinkedList(struct Node* head,struct Node* &head2)
{
    if(head==NULL||head->next==NULL)
    {
        return ;
    }
    Node*p,*q,*r;
    r=NULL;
    p=head;
    q=head;
    while(q!=NULL)
    {
        r=p;
        p=p->next;
        if(q->next==NULL)
            break;
        q=q->next->next;
    }
    head2=p;
    r->next=NULL;
}
void reorderList(Node* head)
{
    if(head==NULL||head->next==NULL)
        return ;
    Node* head2=NULL,*temp=NULL,*p=NULL,*q=NULL;
    breakLinkedList(head,head2);
    head2=reverse(head2);
    p=head;
    q=head2;
    while(q!=NULL)
    {
        temp=newNode(q->data);
        temp->next=p->next;
        p->next=temp;
        p=p->next->next;
        q=q->next;

    }
}
