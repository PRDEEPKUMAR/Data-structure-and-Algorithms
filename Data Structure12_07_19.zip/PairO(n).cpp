#include<bits/stdc++.h>
using namespace std;
int main()
{
     int t,i,n,key;
     cin>>t;
     int B[100000]={0};
     while(t--)
     {
         int f,g;
         cin>>n>>key;
         int A[n];
         for(i=0;i<n;i++)
         {
             cin>>A[i];
             B[A[i]]++;

         }
         f=0;
         for(i=0;i<n;i++)
         {
            g=key-A[i];
            if(g>=0)
            {
                if(B[g]>0)
                {
                  f=1;
                  cout<<" g :"<<g;
                  break;
                }
            }

         }
         if(f==1)
         cout<<"Yes"<<endl;
         else
         cout<<"No"<<endl;


     }
     return 0;
}
