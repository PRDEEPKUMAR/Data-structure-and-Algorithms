#include<iostream>
#include<bits/stdc++.h>
typedef unsigned long long int ulli;
using namespace std;
int main()
{
    int i='a';
    cout<<i<<" "<<int('z');
    return 0;
}

