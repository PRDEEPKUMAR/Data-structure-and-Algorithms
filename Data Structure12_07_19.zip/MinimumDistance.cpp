#include<iostream>
using namespace std;
int main()
{

    int n,j,i,k,mind=100001;
    cin>>n;
    int A[n];
    for(i=0;i<n;i++)
        cin>>A[i];
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(A[i]==A[j])
            {
                if((j-i)<mind)
                mind=j-1;

            }
        }
    }
    cout<<mind;
    return 0;
}
