#include<iostream>
#include<bits/stdc++.h>
using namespace std;
void pattern(int val, bool b,int match)
{

    cout<<val<<" ";
    if(b==true&&val==match)
    {
        return;
    }
    else if(b==false && val>0)
    {
        pattern(val-5,b,match);
    }
    else if(b==true&&val>0)
    {
        pattern(val+5,b,match);
    }
    else if(b==false&&val<=0)
    {
        pattern(val+5,true,match);
    }

}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        bool b;
        int val;
        cin>>val;
        if(val>0)
        {
            b=false;
        }
        else
            b=true;
        pattern(val,b,val);
        cout<<endl;

    }
    return 0;
}
