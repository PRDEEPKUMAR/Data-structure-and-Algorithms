#include <bits/stdc++.h>
using namespace std;
/* A binary tree node has data, pointer to left child
   and a pointer to right child */
struct Node
{
    int data;
    struct Node* left;
    struct Node* right;

    Node(int x){
        data = x;
        left = right = NULL;
    }
};
// A wrapper over rightViewUtil()
void rightView(struct Node *root);
/* Helper function that allocates a new node with the
   given data and NULL left and right pointers. */
/* Driver program to test size function*/
int main()
{
  int t;
  struct Node *child;
  scanf("%d", &t);
  while (t--)
  {
     map<int, Node*> m;
     int n;
     scanf("%d",&n);
     struct Node *root = NULL;
     while (n--)
     {
        Node *parent;
        char lr;
        int n1, n2;
        scanf("%d %d %c", &n1, &n2, &lr);
        if (m.find(n1) == m.end())
        {
           parent = new Node(n1);
           m[n1] = parent;
           if (root == NULL)
             root = parent;
        }
        else
           parent = m[n1];
        child = new Node(n2);
        if (lr == 'L')
          parent->left = child;
        else
          parent->right = child;
        m[n2]  = child;
     }
     rightView(root);
     cout << endl;
  }
  return 0;
}



void rightView(Node *t)
{
     Node* temp;
    queue<Node*> q;
    q.push(t);
    q.push(NULL);
    cout<<t->data<<" ";
    while(!q.empty())
    {
        temp=q.front();
        q.pop();
        if(temp==NULL&&q.front()==NULL)
            return ;
        else if(temp==NULL)
        {
            if(q.front())
            cout<<q.front()->data<<" ";
            q.push(NULL);

        }
        else
            {
                if(temp->left)
                q.push(temp->left);
                if(temp->right)
                q.push(temp->right);
        }
    }
}
