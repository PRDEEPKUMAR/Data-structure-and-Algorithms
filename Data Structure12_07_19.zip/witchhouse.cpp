#include<iostream>
using namespace std;
int main()
{
    int t,n,i,count=0;
    cin>>t;
    while(t--)
    {
        count=0;
        cin>>n;
        char A[n];
        for(i=0;i<n;i++)
            cin>>A[i];
            if(n==1)
            {
                cout<<1;

            }
            else
            {


        for(i=0;i<n;i++)
        {
            if(i==0&&A[0]=='0'&&A[1]=='0')
            {
                A[0]='1';
                count++;
            }
            else if(A[i]=='0'&&A[i+1]=='0')
            {
                A[i+1]='1';
                count++;
            }
           else if(A[i]=='1'&&A[i+1]=='1')
            {
                A[i]=0;
                count--;

            }


        }
        cout<<count<<endl;
            }

    }

    return 0;
}
